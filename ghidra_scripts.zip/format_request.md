For all function marking requests. Return an `INLINE_JSON_DATA` with the following format and information. Additionally, please try to add the following; brief description of expected input and return variables and their meaning with each part having their own line and indent, local variable and value meaning at their declaration/initializations/assignments, any subcall meanings or guesses, and parts where a assumed pass by reference or return value is manipulated with its meaning. Try to be concise where possible and elaborate on any meanings or values that may not be intuitive. If meaning is retained, keep comments to one per decompilation line at maximum. Please mark the start of each comment with your name and a marker such as `[GUESS: 50%]` with your confidence. You will get the disassembly and decompilation for the same function. 

Avoid commenting on assembly instructions or decompiled lines where their meaning or direct action is immediately obvious (e.g., `NOP` instructions, simple register moves without complex context, clear arithmetic operations unless the result's purpose is non-intuitive). Focus comments on inferences, high-level purpose, data flow beyond direct assignment, control flow logic, or non-obvious variable meanings.

Try to identify any direct or potential bugs or vulnerabilities in the code; Include a `[VULN: 50%]` marker with your confidence. When getting decompilation and disassembly, controlled parameters may be specified but otherwise assume input may or may not be user controlled. Please include a concise summary of each vulnerability in the function level description similar to input/outputs.

Beyond function-specific details, also identify all unique global variables and subcalls encountered. For each, suggest a more descriptive `new_name` and provide its `c_type`. For subcalls, also list their estimated `c_type` (return type) and common `parameters` with their `c_type`.

Do not fully trust already marked up portions. If you think there is relevance to change a non-default name then indicate that in a comment and change the new name in the INLINE_JSON_DATA.

Use all available code to derive your results. Do not treat each diassembly / decompile as a isolated instance as you may need to attempt to trace call parameters to derive vulnerabilities.

VERY IMPORTANT: When renaming functions, do not remove or alter existing prefixes like oop::. For example, oop::decode_impl_alternate should remain oop::decode_impl_alternate if no other rename is specified, or if a rename is specified, ensure the oop:: prefix is kept.

When generating the INLINE_JSON_DATA, all string values within the JSON object (e.g., for function_comment, comment fields, new_name, c_type, etc.) must strictly adhere to JSON string escaping rules. This means:

- Newlines (\n) must be escaped as \\n.
- Backslashes (\) must be escaped as \\\\.
- Double quotes (") within a string must be escaped as \\".
- Tabs (\t) must be escaped as \\t.
- Avoid other unescaped control characters (ASCII 0-31)."

```
INLINE_JSON_DATA = {
  "typedef_definitions": [
    {
      "name": "",
      "base_type": "",
      "comment": ""
    }
  ],
  "struct_definitions": [
    {
      "name": "",
      "members": [
        {"name": "", "type": "", "offset": ""},
        {"name": "", "type": "", "offset": "", "comment": ""},
        {"name": "", "type": "", "offset": ""}
      ],
      "comment": ""
    }
  ],
  "function_updates": [
    {
      "function_identification": {
        "address": ""
      },
      "function_metadata": {
        "new_function_name": "",
        "function_comment": ""
      },
      "parameters": [
        {
          "original_name": "",
          "new_name": "",
          "c_type": ""
        }
      ],
      "local_variables": [
        {
          "original_name": "",
          "new_name": "",
          "c_type": "",
          "offset": ""
        }
      ],
      "comments": [
        {
          "address_offset_from_function_start": "",
          "text": ""
        }
      ],
      "global_data_references": [
        {
          "address": "",
          "new_name": "",
          "c_type": "",
          "comment": ""
        }
      ],
      "subcall_target_functions": [
        {
          "address": "",
          "new_function_name": "",
          "demangle": False
        }
      ]
    }
  ]
}
```

