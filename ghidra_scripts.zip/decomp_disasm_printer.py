# decomp_disasm_printer.py (No changes needed for this fix)
# A Ghidra Python script to grab the decompilation and disassembly from function addresses passed as arguments.
# @author chat_gemini
# @category _NEW_
# @menupath _NEW_/Decompilation Disassembly Printer

from ghidra.app.decompiler import DecompInterface
from ghidra.util.task import ConsoleTaskMonitor
from ghidra.program.model.listing import Function, CodeUnit
from ghidra.program.model.address import Address
from ghidra.program.model.symbol import SymbolTable, Symbol, Reference 

import re 
import os 
import tempfile 

# Define the same well-known, fixed path as in the caller script (for addresses)
GHIDRA_SHARED_FILE_PATH = os.path.join(tempfile.gettempdir(), "ghidra_shared_addrs.txt")

# Define the single, common output file path for ALL script output (MUST match the caller)
GHIDRA_OUTPUT_DIR = os.path.join(os.path.expanduser('~'), "Ghidra_Analysis_Output")
UNIFIED_OUTPUT_FILE_PATH = os.path.join(GHIDRA_OUTPUT_DIR, "ghidra_unified_analysis_output.txt")


# Global decompiler interface for efficiency if many functions are processed
decompiler = None

def initialize_decompiler():
    global decompiler
    if decompiler is None:
        decompiler = DecompInterface()
        decompiler.openProgram(currentProgram)

# Helper function to write to the unified output file (takes file_handle)
def write_unified_output(message, file_handle):
    file_handle.write(message + "\n")
    # Optional: print to Ghidra console for immediate feedback on the receiver side
    # print(message)

def get_selected_function(file_handle):
    current_addr = currentLocation.getAddress()
    if current_addr:
        function = getFunctionContaining(current_addr)
        if function:
            return function
    write_unified_output("No function found or selected. Please place your cursor inside the desired function in the Listing view.", file_handle)
    return None

def get_function_by_address(address_string, file_handle):
    try:
        addr = currentProgram.getAddressFactory().getAddress(address_string)
        function = currentProgram.getFunctionManager().getFunctionAt(addr)
        if function:
            return function
        else:
            write_unified_output("No function found at address: {}".format(address_string), file_handle)
            return None
    except Exception as e:
        write_unified_output("Error parsing address string '{}': {}".format(address_string, e), file_handle)
        return None

def get_decompilation(function):
    if not function: return ""
    output_lines = []
    output_lines.append("\n--- Decompiling Function: {} ---".format(function.getName()))
    global decompiler
    if decompiler is None: initialize_decompiler()
    results = decompiler.decompileFunction(function, 0, ConsoleTaskMonitor())
    if results.decompileCompleted():
        decompiled_code = results.getDecompiledFunction().getC()
        # Filter blank lines
        filtered_code_lines = [line for line in decompiled_code.splitlines() if line.strip()]
        output_lines.extend(filtered_code_lines)
        output_lines.append("\n--- Decompilation Complete ---")
    else:
        output_lines.append("Decompilation failed for {}. Status: {}".format(function.getName(), results.getStatus()))
        output_lines.append("Decompiler error message: {}".format(results.getErrorMessage()))
    return "\n".join(output_lines)

def get_disassembly(function):
    if not function: return ""
    output_lines = []
    output_lines.append("\n--- Disassembly for Function: {} ---".format(function.getName()))
    listing = currentProgram.getListing()
    symbol_table = currentProgram.getSymbolTable()
    function_manager = currentProgram.getFunctionManager()
    address_factory = currentProgram.getAddressFactory() 
    body = function.getBody()
    code_units = listing.getCodeUnits(body, True)
    
    # Collect all lines first, then filter blank ones
    raw_disassembly_lines = []
    for unit in code_units:
        instruction = listing.getInstructionAt(unit.getAddress())
        if instruction:
            mnemonic = instruction.getMnemonicString()
            all_instruction_references = instruction.getReferencesFrom()
            operand_parts = []
            for i in range(instruction.getNumOperands()):
                operand_str = instruction.getDefaultOperandRepresentation(i)
                current_operand_references = [ref for ref in all_instruction_references if ref.getOperandIndex() == i]
                resolved_name = None
                if current_operand_references:
                    ref_target_addr = current_operand_references[0].toAddress
                    target_func = function_manager.getFunctionAt(ref_target_addr)
                    if target_func:
                        resolved_name = target_func.getName()
                    else:
                        target_symbol = symbol_table.getPrimarySymbol(ref_target_addr)
                        if target_symbol:
                            resolved_name = target_symbol.getName()
                if resolved_name:
                    hex_matches = re.finditer(r'(?P<prefix>0x)?(?P<addr>[0-9a-fA-F]+)(?P<suffix>h)?', operand_str, re.IGNORECASE)
                    best_match = None 
                    for match in hex_matches:
                        try:
                            potential_addr_str_bare = match.group('addr')
                            matched_ghidra_addr = address_factory.getAddress(potential_addr_str_bare) 
                            if matched_ghidra_addr == ref_target_addr:
                                best_match = match
                                break
                        except:
                            pass 
                    if best_match:
                        start_idx = best_match.start() 
                        end_idx = best_match.end()     
                        operand_str = operand_str[:start_idx] + resolved_name + operand_str[end_idx:]
                operand_parts.append(operand_str)
            operand_string = ", ".join(operand_parts)
            full_instruction_str = "{}: {:<10} {}".format(instruction.getAddress(), mnemonic, operand_string) 
            raw_disassembly_lines.append(full_instruction_str)
    
    # Filter blank lines from the raw disassembly
    filtered_disassembly_lines = [line for line in raw_disassembly_lines if line.strip()]
    output_lines.extend(filtered_disassembly_lines)
    
    output_lines.append("\n--- Disassembly Complete ---")
    return "\n".join(output_lines)


def main():
    # Open the unified output file in APPEND mode ('a') to add to existing content
    with open(UNIFIED_OUTPUT_FILE_PATH, 'a') as out_file:
        write_unified_output("\n--- decomp_disasm_printer.py: Script started (appending to unified output) ---", out_file)

        function_addresses_str = []
        
        # Communication via FIXED shared file
        if os.path.exists(GHIDRA_SHARED_FILE_PATH):
            try:
                with open(GHIDRA_SHARED_FILE_PATH, 'r') as f:
                    for line in f:
                        function_addresses_str.append(line.strip()) 
            except Exception as e:
                write_unified_output("decomp_disasm_printer.py: Error reading fixed file {}: {}".format(GHIDRA_SHARED_FILE_PATH, e), out_file)
            finally:
                if os.path.exists(GHIDRA_SHARED_FILE_PATH):
                    try:
                        os.remove(GHIDRA_SHARED_FILE_PATH)
                    except Exception as e:
                        write_unified_output("decomp_disasm_printer.py: Error cleaning up fixed file {}: {}".format(GHIDRA_SHARED_FILE_PATH, e), out_file)
        else:
            write_unified_output("decomp_disasm_printer.py: Fixed file '{}' not found. Falling back to selected function.".format(GHIDRA_SHARED_FILE_PATH), out_file)
            target_function = get_selected_function(out_file)
            if target_function:
                functions_to_process = [target_function]
            else:
                write_unified_output("decomp_disasm_printer.py: No function to process.", out_file)
                return 

        # If addresses were read from file, now process them
        if function_addresses_str:
            functions_to_process = []
            for addr_str in function_addresses_str:
                func = get_function_by_address(addr_str, out_file)
                if func:
                    functions_to_process.append(func)
        elif 'functions_to_process' not in locals(): 
            functions_to_process = [] 

        if not functions_to_process:
            write_unified_output("decomp_disasm_printer.py: No valid functions found from provided data or selection.", out_file)
            return

        initialize_decompiler()
        
        for function in functions_to_process:
            decompilation_output = get_decompilation(function)
            write_unified_output(decompilation_output, out_file)

            disassembly_output = get_disassembly(function)
            write_unified_output(disassembly_output, out_file)
        
        if decompiler is not None:
            decompiler.dispose()
        
        write_unified_output("\n--- decomp_disasm_printer.py: Script finished. ---", out_file)
        write_unified_output("-" * 80, out_file)


if __name__ == '__main__':
    main()