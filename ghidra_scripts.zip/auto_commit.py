# AutoCommitFunctionMarks.py
# Ghidra Python script to automatically apply function, parameter, and local variable renames and types.

from ghidra.program.model.address import Address
from ghidra.program.model.data import DataType, VoidDataType, PointerDataType, FunctionDefinitionDataType
from ghidra.program.model.symbol import SourceType
from ghidra.program.model.listing import ParameterImpl, Variable, LocalVariableImpl

def get_data_type(type_string):
    """
    Attempts to resolve a C-style type string to a Ghidra DataType.
    """
    dtm = currentProgram.getDataTypeManager()
    
    # Handle common base types directly
    if type_string == "void": return VoidDataType.dataType
    if type_string == "int": return dtm.getBuiltInDataType("int")
    if type_string == "longlong": return dtm.getBuiltInDataType("long long")
    if type_string == "char": return dtm.getBuiltInDataType("char")
    if type_string == "uint8_t": return dtm.getBuiltInDataType("byte") # Or unsigned char
    if type_string == "bool": return dtm.getBuiltInDataType("bool")
    
    # Handle pointers
    if type_string.endswith("*"):
        base_type_str = type_string[:-1].strip()
        base_dt = get_data_type(base_type_str)
        if base_dt:
            return PointerDataType(base_dt, dtm)
        else:
            # Fallback for unknown base types for pointers
            return dtm.getBuiltInDataType("void").getPointer(dtm)

    # Handle specific Ghidra type names you might have defined or want to use
    if type_string == "code": # For 'code *' (often represents a function pointer)
        # Assuming 'code' implies a function pointer for now, can be refined.
        return dtm.getBuiltInDataType("void").getPointer(dtm) 
    if type_string == "VM_Operation": # If you had a struct defined for it
        struct_dt = dtm.getDataType("/VM_Operation") # Adjust path if different, e.g., "/Structures/VM_Operation"
        if struct_dt: return struct_dt
    if type_string == "JavaThread":
        thread_dt = dtm.getDataType("/JavaThread") # Adjust path
        if thread_dt: return thread_dt
    
    # Generic fallback if nothing specific matches
    return dtm.getBuiltInDataType("void")

def get_function_at_address(address_str):
    """Retrieves a Ghidra Function object at a given address string."""
    addr = toAddr(address_str)
    if addr is None:
        printerr("Invalid address string: {}".format(address_str))
        return None
    func = currentProgram.getFunctionManager().getFunctionAt(addr)
    if func is None:
        printerr("No function found at address: {}".format(address_str))
    return func

def get_function_update_proposals(func_addr_str):
    """
    Generates proposed renames and types for a specific function.
    This part is your analysis logic.
    """
    proposals = {}
    func = get_function_at_address(func_addr_str)
    if not func:
        return None

    proposals["address"] = func_addr_str
    proposals["original_name"] = func.getName()
    proposals["proposed_name"] = "VM_Operation::evaluate" 

    # Parameters
    # This section needs to intelligently identify and propose for parameters.
    # We will assume 'param_1' for this specific case based on the decompilation.
    params_info = []
    ghidra_params = func.getParameters()
    
    # Check if a parameter like 'param_1' or 'arg1' (Ghidra's default) exists
    found_param_1 = None
    if ghidra_params and len(ghidra_params) > 0:
        for p in ghidra_params:
            # Prioritize 'param_1' if it's the exact decomp name, else check common defaults
            if p.getName() == "param_1" or p.getOrdinal() == 0: 
                found_param_1 = p
                break
    
    if found_param_1:
        params_info.append({
            "original_name": found_param_1.getName(),
            "proposed_name": "this_ptr",
            "proposed_type": "void*", # More specific: "VM_Operation*" if you define it
            "ghidra_param_obj": found_param_1
        })
    else:
        # If Ghidra hasn't identified parameters yet, or named them differently,
        # you might need to try to define a new parameter for the function,
        # which is more involved (e.g., func.insertParameter(0, "this_ptr", get_data_type("void*"), SourceType.USER_DEFINED))
        # For simplicity, this script will only apply to existing recognized parameters.
        print("[*] Warning: Could not find parameter 'param_1' or first argument for function {}. Skipping parameter rename.".format(func.getName()))

    proposals["parameters"] = params_info

    # Local Variables
    locals_info = []
    ghidra_locals = func.getLocalVariables()
    for lv in ghidra_locals:
        if lv.getName() == "pcVar1": # This is the decompiler's name
            locals_info.append({
                "original_name": lv.getName(),
                "proposed_name": "breakpoint_handler_return_ptr",
                "proposed_type": "code*",
                "ghidra_local_obj": lv
            })
            break 
    else: # This else block runs if the loop completes without a 'break'
        print("[*] Warning: Could not find local variable 'pcVar1' for function {}. Skipping local variable rename.".format(func.getName()))


    proposals["local_variables"] = locals_info
    
    return proposals

def apply_changes_automatically(function_proposals):
    """
    Automatically applies the proposed renames and types to the Ghidra database.
    No user interaction.
    """
    if not function_proposals:
        print("[-] No proposals to apply.")
        return

    # Start a transaction for atomic database updates
    txId = currentProgram.startTransaction("Auto-Apply Function Marks")
    try:
        func = get_function_at_address(function_proposals["address"])
        if not func:
            return

        # --- Apply Function Name ---
        final_func_name = function_proposals['proposed_name']
        if final_func_name != func.getName():
            monitor.setMessage("Renaming function to {}...".format(final_func_name))
            func.setName(final_func_name, SourceType.USER_DEFINED)
            print("[+] Function renamed to: {}".format(final_func_name))
        else:
            print("[*] Function name already '{}', no change needed.".format(final_func_name))

        # --- Apply Parameters ---
        if function_proposals["parameters"]:
            for param_prop in function_proposals["parameters"]:
                param_obj = param_prop["ghidra_param_obj"]
                final_p_name = param_prop['proposed_name']
                final_p_type_str = param_prop['proposed_type']
                
                # Rename parameter
                if final_p_name != param_obj.getName():
                    monitor.setMessage("Renaming parameter {} to {}...".format(param_obj.getName(), final_p_name))
                    param_obj.setName(final_p_name, SourceType.USER_DEFINED)
                    print("[+] Parameter '{}' renamed to: {}".format(param_prop['original_name'], final_p_name))
                else:
                    print("[*] Parameter '{}' name already '{}', no change needed.".format(param_prop['original_name'], final_p_name))

                # Set parameter type
                proposed_dt = get_data_type(final_p_type_str)
                if proposed_dt and proposed_dt != param_obj.getDataType():
                    monitor.setMessage("Setting type for parameter {} to {}...".format(param_obj.getName(), proposed_dt.getDisplayName()))
                    param_obj.setDataType(proposed_dt, SourceType.USER_DEFINED)
                    print("[+] Parameter '{}' type set to: {}".format(param_obj.getName(), proposed_dt.getDisplayName()))
                elif not proposed_dt:
                    print("[-] Could not resolve type '{}' for parameter '{}'. Type not changed.".format(final_p_type_str, param_obj.getName()))
                else:
                    print("[*] Parameter '{}' type already '{}', no change needed.".format(param_obj.getName(), proposed_dt.getDisplayName()))
        else:
            print("[*] No parameters identified in proposals for this function.")

        # --- Apply Local Variables ---
        if function_proposals["local_variables"]:
            for local_prop in function_proposals["local_variables"]:
                local_obj = local_prop["ghidra_local_obj"]
                final_l_name = local_prop['proposed_name']
                final_l_type_str = local_prop['proposed_type']
                
                # Rename local variable
                if final_l_name != local_obj.getName():
                    monitor.setMessage("Renaming local variable {} to {}...".format(local_obj.getName(), final_l_name))
                    local_obj.setName(final_l_name, SourceType.USER_DEFINED)
                    print("[+] Local variable '{}' renamed to: {}".format(local_prop['original_name'], final_l_name))
                else:
                    print("[*] Local variable '{}' name already '{}', no change needed.".format(local_prop['original_name'], final_l_name))

                # Set local variable type
                proposed_dt = get_data_type(final_l_type_str)
                if proposed_dt and proposed_dt != local_obj.getDataType():
                    monitor.setMessage("Setting type for local variable {} to {}...".format(local_obj.getName(), proposed_dt.getDisplayName()))
                    local_obj.setDataType(proposed_dt, SourceType.USER_DEFINED)
                    print("[+] Local variable '{}' type set to: {}".format(local_obj.getName(), proposed_dt.getDisplayName()))
                elif not proposed_dt:
                    print("[-] Could not resolve type '{}' for local variable '{}'. Type not changed.".format(final_l_type_str, local_obj.getName()))
                else:
                    print("[*] Local variable '{}' type already '{}', no change needed.".format(local_obj.getName(), proposed_dt.getDisplayName()))
        else:
            print("[*] No local variables identified in proposals for this function.")

        print("[+] All proposed changes applied automatically.")

    except Exception as e:
        printerr("[-] An error occurred during automatic application: {}".format(e))
    finally:
        currentProgram.endTransaction(txId, True) # Commit the transaction (True)
        print("[*] Automatic marking process complete.")

# --- Main execution ---
if __name__ == '__main__':
    # Define the address of the function you want to process automatically
    # This should be the entry point address of VM_Operation::evaluate (0x18042b700)
    function_address_to_process = "0x18042b700" 

    print("[*] Starting automatic analysis and application for function at {}...".format(function_address_to_process))
    proposals = get_function_update_proposals(function_address_to_process)

    if proposals:
        apply_changes_automatically(proposals)
    else:
        printerr("[-] Could not generate proposals for function at {}. Please ensure it exists and is defined.".format(function_address_to_process))