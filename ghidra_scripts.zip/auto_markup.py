# -*- coding: utf-8 -*-
# Ghidra Python script to import analysis from JSON data

import json
from ghidra.program.model.address import Address
from ghidra.program.model.symbol import SourceType, SymbolType
from ghidra.program.model.listing import Parameter, CodeUnit, Variable, LocalVariable, VariableStorage
from ghidra.program.model.data import DataType, DataTypeManager, PointerDataType, UnsignedIntegerDataType, BooleanDataType, VoidDataType, StructureDataType, Structure, LongLongDataType, IntegerDataType, TypedefDataType, ArrayDataType, CategoryPath, Undefined1DataType
from ghidra.app.util.demangler import DemangledObject, DemanglerOptions, Demangler
from ghidra.program.model.data import DataUtilities
from ghidra.program.model.listing import ParameterImpl
# No longer needed: from ghidra.program.model.data import ParameterDefinitionImpl
from ghidra.program.model.listing import VariableUtilities

from ghidra.app.decompiler import DecompInterface
from ghidra.app.decompiler import DecompileResults
from ghidra.program.model.listing import Function
from ghidra.program.model.pcode import HighFunction
from ghidra.program.model.pcode import HighFunctionDBUtil
from ghidra.program.model.symbol import SourceType
from java.lang.reflect import Array
from ghidra.program.model.pcode import HighFunctionDBUtil
from ghidra.program.model.pcode.HighFunctionDBUtil import ReturnCommitOption
from ghidra.program.model.symbol import SourceType


# PASTE YOUR FULL JSON CONTENT HERE BETWEEN THE TRIPLE QUOTES
INLINE_JSON_DATA = {
  "typedef_definitions": [],
  "struct_definitions": [],
  "function_updates": [
    {
      "function_identification": {
        "address": "18000d500"
      },
      "function_metadata": {
        "new_function_name": "ai_return_zero",
        "function_comment": "This function simply returns a null/zero value. Its specific purpose beyond returning zero is unclear without more context, but it might be a placeholder or a function used for initialization or a default 'no-op' operation where a non-zero return value would indicate an error or success."
      },
      "parameters": [],
      "local_variables": [],
      "comments": [],
      "global_data_references": [],
      "subcall_target_functions": []
    },
    {
      "function_identification": {
        "address": "180348340"
      },
      "function_metadata": {
        "new_function_name": "ai_JVM_Thread_Cleanup",
        "function_comment": "This function appears to perform a cleanup operation on a thread-related structure. It checks two conditions related to `param_1` and `param_1[1]` and, if met, updates `param_1[1]` with a value from an offset of `*param_1`.\n\nVulnerability: [VULN: 30%] Potential Null Pointer Dereference: If `*param_1` is non-zero but points to an invalid or unmapped memory region, the access `*(longlong *)(*param_1 + -8)` could lead to a read access violation."
      },
      "parameters": [
        {
          "original_name": "param_1",
          "new_name": "ai_thread_data",
          "c_type": "long long *"
        }
      ],
      "local_variables": [],
      "comments": [
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 70%] `param_1` points to a `long long` value, likely the start of a thread data structure or a pointer within it."
        },
        {
          "address_offset_from_function_start": "0x11",
          "text": "ai_[GUESS: 80%] The condition `(*param_1 == 0 || (param_1[1] == 0))` checks if the first element or the second element (at offset +8) of the `long long` array pointed to by `param_1` is zero."
        },
        {
          "address_offset_from_function_start": "0x1d",
          "text": "ai_[GUESS: 90%] If the conditions are met, `param_1[1]` (the long long at offset +8 from `param_1`) is updated with the `long long` value located at `*param_1 - 8`. This could be a way of restoring a previous pointer or clearing a state."
        }
      ],
      "global_data_references": [],
      "subcall_target_functions": []
    },
    {
      "function_identification": {
        "address": "1803daa70"
      },
      "function_metadata": {
        "new_function_name": "ai_process_thread_state",
        "function_comment": "This function appears to handle some kind of thread state processing. It first calls `FUN_1806fc320` with an offset of `param_1`. Based on its return value, it either returns true immediately or calls `FUN_1803da470` and then `FUN_1806fc390`. The boolean return value indicates the success or failure of the operation."
      },
      "parameters": [
        {
          "original_name": "param_1",
          "new_name": "ai_thread_context_ptr",
          "c_type": "long long"
        },
        {
          "original_name": "param_2",
          "new_name": "ai_flag_one",
          "c_type": "undefined1"
        },
        {
          "original_name": "param_3",
          "new_name": "ai_flag_two",
          "c_type": "undefined1"
        }
      ],
      "local_variables": [
        {
          "original_name": "cVar1",
          "new_name": "ai_check_result",
          "c_type": "char",
          "offset": "0x0"
        },
        {
          "original_name": "lVar2",
          "new_name": "ai_subcall_result",
          "c_type": "long long",
          "offset": "0x8"
        },
        {
          "original_name": "bVar3",
          "new_name": "ai_function_success",
          "c_type": "bool",
          "offset": "0x10"
        }
      ],
      "comments": [
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 70%] `cVar1` is a character type, likely storing a boolean or an enumerated result from the subcall."
        },
        {
          "address_offset_from_function_start": "0x1",
          "text": "ai_[GUESS: 70%] `lVar2` stores the return value from `FUN_1803da470`, which is a long long."
        },
        {
          "address_offset_from_function_start": "0x2",
          "text": "ai_[GUESS: 90%] `bVar3` will store the final boolean result of this function."
        },
        {
          "address_offset_from_function_start": "0x11",
          "text": "ai_[GUESS: 80%] `FUN_1806fc320` is called with `param_1 + 0x10`. This suggests that the function operates on a specific field or sub-structure within the data pointed to by `param_1`."
        },
        {
          "address_offset_from_function_start": "0x15",
          "text": "ai_[GUESS: 90%] If `cVar1` is null (false), `bVar3` is set to true, indicating a successful outcome or that further processing is not needed."
        },
        {
          "address_offset_from_function_start": "0x18",
          "text": "ai_[GUESS: 80%] `FUN_1803da470` is called with the original `param_1` and the other two parameters. This suggests it performs a more involved operation."
        },
        {
          "address_offset_from_function_start": "0x1b",
          "text": "ai_[GUESS: 90%] `bVar3` is set based on whether `lVar2` (the result of `FUN_1803da470`) is non-zero (true) or zero (false)."
        },
        {
          "address_offset_from_function_start": "0x1e",
          "text": "ai_[GUESS: 80%] `FUN_1806fc390` is called with `param_1 + 0x10`, likely for cleanup or to release a resource that `FUN_1806fc320` might have acquired or checked."
        }
      ],
      "global_data_references": [],
      "subcall_target_functions": [
        {
          "address": "1806fc320",
          "new_function_name": "ai_check_thread_flag",
          "demangle": False
        },
        {
          "address": "1803da470",
          "new_function_name": "ai_perform_thread_action",
          "demangle": False
        },
        {
          "address": "1806fc390",
          "new_function_name": "ai_release_critical_section",
          "demangle": False
        }
      ]
    },
    {
      "function_identification": {
        "address": "18042d030"
      },
      "function_metadata": {
        "new_function_name": "ai_Thread__vm_state_exit",
        "function_comment": "This function handles the exit process for a VM (Virtual Machine) thread. It performs cleanup operations, potentially enters a safepoint synchronization block, and might execute VM operations based on various thread state flags. There are multiple cleanup and state transition steps involved, and it includes a loop that continues as long as a specific bit in the thread's state flag is set.\n\nVulnerability: [VULN: 40%] Unbounded Loop/Resource Exhaustion: The `do-while` loop at the end of the function (`do { ... } while ((*(uint *)(param_1 + 0x450) >> 3 & 1) != 0);`) relies on a bit flag at `param_1 + 0x450` to become zero. If this bit is never cleared due to logical errors or external conditions, the loop could run indefinitely, leading to a denial-of-service or resource exhaustion. While there's a nested `for` loop, its condition `uVar4 < 0xa000` only limits the inner loop, not the outer `do-while`."
      },
      "parameters": [
        {
          "original_name": "param_1",
          "new_name": "ai_thread_object",
          "c_type": "long long"
        }
      ],
      "local_variables": [
        {
          "original_name": "uVar1",
          "new_name": "ai_thread_state_flag",
          "c_type": "uint",
          "offset": "0x0"
        },
        {
          "original_name": "lVar2",
          "new_name": "ai_crit_section_ptr",
          "c_type": "long long",
          "offset": "0x8"
        },
        {
          "original_name": "cVar3",
          "new_name": "ai_cleanup_status",
          "c_type": "char",
          "offset": "0x10"
        },
        {
          "original_name": "uVar4",
          "new_name": "ai_loop_counter",
          "c_type": "uint",
          "offset": "0x14"
        },
        {
          "original_name": "bVar5",
          "new_name": "ai_is_safepoint_blocked",
          "c_type": "bool",
          "offset": "0x18"
        },
        {
          "original_name": "local_38",
          "new_name": "ai_local_buffer",
          "c_type": "undefined1[16]",
          "offset": "-0x38"
        },
        {
          "original_name": "local_28",
          "new_name": "ai_current_count",
          "c_type": "uint",
          "offset": "-0x28"
        },
        {
          "original_name": "local_20",
          "new_name": "ai_max_count",
          "c_type": "uint",
          "offset": "-0x20"
        }
      ],
      "comments": [
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 80%] `uVar1` stores a thread state flag, likely from `param_1 + 0x450`."
        },
        {
          "address_offset_from_function_start": "0x4",
          "text": "ai_[GUESS: 70%] `lVar2` seems to hold a pointer to a critical section or similar synchronization object, initialized from `DAT_180cc1b60`."
        },
        {
          "address_offset_from_function_start": "0x8",
          "text": "ai_[GUESS: 60%] `cVar3` stores a character result from subcalls, likely indicating success or failure of cleanup/state change operations."
        },
        {
          "address_offset_from_function_start": "0xc",
          "text": "ai_[GUESS: 90%] `uVar4` is a loop counter used in the inner `for` loop."
        },
        {
          "address_offset_from_function_start": "0x10",
          "text": "ai_[GUESS: 80%] `bVar5` is a boolean flag indicating if `DAT_180cc5398` is not equal to 1, possibly controlling safepoint behavior."
        },
        {
          "address_offset_from_function_start": "0x1c",
          "text": "ai_[GUESS: 90%] `local_38` is an array of undefined bytes, used as a buffer for `FUN_1807b5dc0`."
        },
        {
          "address_offset_from_function_start": "0x2c",
          "text": "ai_[GUESS: 70%] `local_28` is a counter, incremented within a loop and compared with `local_20`."
        },
        {
          "address_offset_from_function_start": "0x34",
          "text": "ai_[GUESS: 70%] `local_20` appears to be a limit or maximum count for `local_28`."
        },
        {
          "address_offset_from_function_start": "0x34",
          "text": "ai_[GUESS: 90%] Checks if the 3rd bit (0x8) of the dword at `param_1 + 0x450` is set. This likely indicates a specific thread state, such as 'thread in VM' or 'safepoint requested'."
        },
        {
          "address_offset_from_function_start": "0x40",
          "text": "ai_[GUESS: 90%] Calls `JVM_Thread_Cleanup` on a structure at `param_1 + 0x3a8`. This is likely a specific thread-local data structure requiring cleanup."
        },
        {
          "address_offset_from_function_start": "0x44",
          "text": "ai_[GUESS: 90%] Sets `bVar5` based on whether the global variable `DAT_180cc5398` is not equal to 1. This variable might control certain safepoint or thread state transitions."
        },
        {
          "address_offset_from_function_start": "0x4c",
          "text": "ai_[GUESS: 90%] Calls `JVM_Thread_Cleanup` again on the same structure. This might be a double-check or part of a two-phase cleanup."
        },
        {
          "address_offset_from_function_start": "0x50",
          "text": "ai_[GUESS: 90%] Sets the dword at `param_1 + 0x454` to 10. This likely represents a change in the thread's sub-state or status within the VM."
        },
        {
          "address_offset_from_function_start": "0x57",
          "text": "ai_[GUESS: 90%] Assigns the value of `DAT_180cc1b60` to `lVar2`. This global variable seems to be a pointer or handle to a critical section or synchronization object."
        },
        {
          "address_offset_from_function_start": "0x5a",
          "text": "ai_[GUESS: 80%] Conditional block: if `bVar5` is true, a specific path related to safepoint handling or thread blocking is taken."
        },
        {
          "address_offset_from_function_start": "0x5e",
          "text": "ai_[GUESS: 80%] `FUN_1807b5dc0` is called with `local_38`, `0xa000`, `0x40`, and `1000`. This looks like an initialization of `local_38` with some parameters, possibly related to timing or a thread-specific counter."
        },
        {
          "address_offset_from_function_start": "0x63",
          "text": "ai_[GUESS: 90%] `uVar1` is updated with the current value of the thread state flag at `param_1 + 0x450`."
        },
        {
          "address_offset_from_function_start": "0x69",
          "text": "ai_[GUESS: 90%] Loop condition: continues as long as the 3rd bit of `uVar1` is set AND `uVar4` is less than `0xa000`."
        },
        {
          "address_offset_from_function_start": "0x70",
          "text": "ai_[GUESS: 80%] If `local_28` is less than `local_20`, increment `local_28` and call `FUN_18000d500` (which returns 0)."
        },
        {
          "address_offset_from_function_start": "0x78",
          "text": "ai_[GUESS: 80%] Otherwise (if `local_28` is not less than `local_20`), call `FUN_1807b5df0` with `local_38`."
        },
        {
          "address_offset_from_function_start": "0x7e",
          "text": "ai_[GUESS: 90%] `uVar1` is re-read from `param_1 + 0x450` to check the loop condition for the next iteration."
        },
        {
          "address_offset_from_function_start": "0x81",
          "text": "ai_[GUESS: 90%] Increment `uVar4`, the inner loop counter."
        },
        {
          "address_offset_from_function_start": "0x84",
          "text": "ai_[GUESS: 90%] Set `bVar5` to false after this block, indicating that this specific 'safepoint-related' action has been handled."
        },
        {
          "address_offset_from_function_start": "0x89",
          "text": "ai_[GUESS: 80%] Else block: executed if `bVar5` was false initially. This path handles synchronization and cleanup if `bVar5` was false."
        },
        {
          "address_offset_from_function_start": "0x8b",
          "text": "ai_[GUESS: 80%] If `DAT_180cc1b60` is not zero, call `FUN_1806fc0f0` with `DAT_180cc1b60` and `param_1`. This looks like acquiring or performing an action related to the critical section."
        },
        {
          "address_offset_from_function_start": "0x91",
          "text": "ai_[GUESS: 90%] If the 3rd bit of the thread state flag is still set, call `FUN_1806fc4b0` with `lVar2` (the critical section pointer) and 0."
        },
        {
          "address_offset_from_function_start": "0x97",
          "text": "ai_[GUESS: 80%] If `lVar2` (the critical section pointer) is not zero, call `FUN_1806fc390` with `lVar2`. This likely releases the critical section."
        },
        {
          "address_offset_from_function_start": "0x9d",
          "text": "ai_[GUESS: 90%] Sets the dword at `param_1 + 0x454` to 6. This is another thread sub-state change, possibly indicating 'thread leaving VM' or 'ready for safepoint exit'."
        },
        {
          "address_offset_from_function_start": "0xa7",
          "text": "ai_[GUESS: 90%] Calls `SafepointSynchronize::block()`. This is a critical synchronization point, likely blocking until it's safe for the thread to proceed (e.g., after a safepoint)."
        },
        {
          "address_offset_from_function_start": "0xae",
          "text": "ai_[GUESS: 90%] Checks if the lowest bit of the qword at `param_1 + 0x28` is set. This might be another thread status flag."
        },
        {
          "address_offset_from_function_start": "0xb4",
          "text": "ai_[GUESS: 80%] Conditional block: if `DAT_180cc9fe0` is zero."
        },
        {
          "address_offset_from_function_start": "0xb8",
          "text": "ai_[GUESS: 80%] Calls `FUN_1803daa70` with `param_1 + 0x588`, 1, and 0. This seems to be another state transition or validation function for a different part of the thread object."
        },
        {
          "address_offset_from_function_start": "0xc0",
          "text": "ai_[GUESS: 80%] If `cVar3` (result of `FUN_1803daa70`) is false AND `FUN_1807c2aa0(param_1)` returns true."
        },
        {
          "address_offset_from_function_start": "0xc7",
          "text": "ai_[GUESS: 90%] Calls `FUN_1807960b0` with `param_1`. This seems to be a finalization step or a transition to another state before exiting the main loop."
        },
        {
          "address_offset_from_function_start": "0xcb",
          "text": "ai_[GUESS: 90%] Jumps to `LAB_18042d190` (end of the main loop) if the previous conditions were met."
        },
        {
          "address_offset_from_function_start": "0xd3",
          "text": "ai_[GUESS: 90%] If the lowest bit of the qword at `param_1 + 0x28` is still set, call `VM_Operation::exit_safepoint`."
        },
        {
          "address_offset_from_function_start": "0xe6",
          "text": "ai_[GUESS: 90%] Main loop condition: continues as long as the 3rd bit of the dword at `param_1 + 0x450` is set."
        },
        {
          "address_offset_from_function_start": "0xf1",
          "text": "ai_[GUESS: 90%] After the main loop, checks if the 2nd bit (0x4) of the dword at `param_1 + 0x450` is set."
        },
        {
          "address_offset_from_function_start": "0xf8",
          "text": "ai_[GUESS: 90%] If the 2nd bit is set, calls `FUN_180474bc0` with `param_1`."
        }
      ],
      "global_data_references": [
        {
          "address": "180cc5398",
          "new_name": "ai_global_state_flag_one",
          "c_type": "uint",
          "comment": "ai_A global flag or counter, likely indicating a system-wide state or a specific mode of operation. Checked multiple times for thread state transitions."
        },
        {
          "address": "180cc1b60",
          "new_name": "ai_global_crit_section_handle",
          "c_type": "long long",
          "comment": "ai_A global pointer or handle to a critical section or similar synchronization primitive."
        },
        {
          "address": "180cc9fe0",
          "new_name": "ai_global_debug_flag",
          "c_type": "uint",
          "comment": "ai_A global flag, possibly indicating a debug mode or a condition that bypasses certain operations."
        }
      ],
      "subcall_target_functions": [
        {
          "address": "180348340",
          "new_function_name": "ai_JVM_Thread_Cleanup",
          "demangle": False
        },
        {
          "address": "1807b5dc0",
          "new_function_name": "ai_initialize_thread_perf_data",
          "demangle": False
        },
        {
          "address": "18000d500",
          "new_function_name": "ai_return_zero",
          "demangle": False
        },
        {
          "address": "1807b5df0",
          "new_function_name": "ai_measure_thread_activity",
          "demangle": False
        },
        {
          "address": "1806fc0f0",
          "new_function_name": "ai_acquire_critical_section",
          "demangle": False
        },
        {
          "address": "1806fc4b0",
          "new_function_name": "ai_wait_for_condition_or_tls",
          "demangle": False
        },
        {
          "address": "1806fc390",
          "new_function_name": "ai_release_critical_section",
          "demangle": False
        },
        {
          "address": "18071f9c0",
          "new_function_name": "ai_SafepointSynchronize__block",
          "demangle": False
        },
        {
          "address": "1803daa70",
          "new_function_name": "ai_process_thread_state",
          "demangle": False
        },
        {
          "address": "1807c2aa0",
          "new_function_name": "ai_check_thread_cleanup_complete",
          "demangle": False
        },
        {
          "address": "1807960b0",
          "new_function_name": "ai_thread_safepoint_post_processing",
          "demangle": False
        },
        {
          "address": "180796000",
          "new_function_name": "ai_VM_Operation__exit_safepoint",
          "demangle": False
        },
        {
          "address": "180474bc0",
          "new_function_name": "ai_handle_thread_suspend",
          "demangle": False
        }
      ]
    },
    {
      "function_identification": {
        "address": "180474bc0"
      },
      "function_metadata": {
        "new_function_name": "ai_handle_thread_suspend",
        "function_comment": "This function appears to handle a thread suspension or a similar state transition. It checks a specific bit in `param_1 + 0x450` to determine its behavior. If the bit is not set, it may acquire a critical section (if `DAT_180cc1d90` is valid), sets a flag in `param_1 + 0x30c`, and then enters a loop. Inside the loop, it repeatedly calls `FUN_1806fc4b0` until the specific bit in `param_1 + 0x450` becomes set. Finally, it clears the flag in `param_1 + 0x30c` and potentially releases the critical section.\n\nVulnerability: [VULN: 30%] Potential Deadlock/Infinite Loop: The `while` loop condition `(~bVar2 & 1) == 0` (effectively `bVar2 == 1`) depends on the 2nd bit of `*(uint *)(param_1 + 0x450)` being clear. If this bit is never cleared externally, the loop will run indefinitely, leading to a hang or denial-of-service."
      },
      "parameters": [
        {
          "original_name": "param_1",
          "new_name": "ai_thread_object",
          "c_type": "long long"
        }
      ],
      "local_variables": [
        {
          "original_name": "lVar1",
          "new_name": "ai_crit_section_ptr",
          "c_type": "long long",
          "offset": "0x0"
        },
        {
          "original_name": "bVar2",
          "new_name": "ai_thread_state_bit",
          "c_type": "byte",
          "offset": "0x8"
        }
      ],
      "comments": [
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 80%] `lVar1` stores the value of `DAT_180cc1d90`, likely a pointer to a critical section or synchronization object."
        },
        {
          "address_offset_from_function_start": "0x8",
          "text": "ai_[GUESS: 80%] `bVar2` stores the value of the 2nd bit (0x4) from the dword at `param_1 + 0x450`, representing a thread state or flag."
        },
        {
          "address_offset_from_function_start": "0xc",
          "text": "ai_[GUESS: 90%] Checks if the 2nd bit (0x4) of the dword at `param_1 + 0x450` is NOT set. If it is set, the function returns early."
        },
        {
          "address_offset_from_function_start": "0x12",
          "text": "ai_[GUESS: 80%] If `DAT_180cc1d90` is not zero, call `FUN_1806fc120` with `DAT_180cc1d90`. This looks like acquiring a lock or performing an action on a synchronization object."
        },
        {
          "address_offset_from_function_start": "0x17",
          "text": "ai_[GUESS: 90%] Sets the dword at `param_1 + 0x30c` to 1. This might be a 'thread suspended' or 'busy' flag within the thread object."
        },
        {
          "address_offset_from_function_start": "0x1b",
          "text": "ai_[GUESS: 90%] `bVar2` is re-read from `param_1 + 0x450` (specifically the 2nd bit)."
        },
        {
          "address_offset_from_function_start": "0x20",
          "text": "ai_[GUESS: 90%] Loop condition: continues as long as the 2nd bit of `*(uint *)(param_1 + 0x450)` is NOT set."
        },
        {
          "address_offset_from_function_start": "0x23",
          "text": "ai_[GUESS: 90%] Calls `FUN_1806fc4b0` with `lVar1` (the critical section pointer) and 0. This could be a wait operation."
        },
        {
          "address_offset_from_function_start": "0x26",
          "text": "ai_[GUESS: 90%] `bVar2` is updated from `param_1 + 0x450` for the next loop iteration."
        },
        {
          "address_offset_from_function_start": "0x2d",
          "text": "ai_[GUESS: 90%] Sets the dword at `param_1 + 0x30c` to 0. This clears the 'suspended' or 'busy' flag."
        },
        {
          "address_offset_from_function_start": "0x33",
          "text": "ai_[GUESS: 80%] If `lVar1` (the critical section pointer) is not zero, call `FUN_1806fc390` with `lVar1`. This likely releases the critical section."
        }
      ],
      "global_data_references": [
        {
          "address": "180cc1d90",
          "new_name": "ai_global_suspend_crit_section",
          "c_type": "long long",
          "comment": "ai_A global pointer or handle to a critical section, possibly used for thread suspension/resumption synchronization."
        }
      ],
      "subcall_target_functions": [
        {
          "address": "1806fc120",
          "new_function_name": "ai_acquire_suspend_lock",
          "demangle": False
        },
        {
          "address": "1806fc4b0",
          "new_function_name": "ai_wait_for_condition_or_tls",
          "demangle": False
        },
        {
          "address": "1806fc390",
          "new_function_name": "ai_release_critical_section",
          "demangle": False
        }
      ]
    },
    {
      "function_identification": {
        "address": "1806fc0f0"
      },
      "function_metadata": {
        "new_function_name": "ai_acquire_critical_section",
        "function_comment": "This function enters a critical section and sets the first member of the critical section structure to `param_2`. It's a standard pattern for protecting shared resources."
      },
      "parameters": [
        {
          "original_name": "param_1",
          "new_name": "ai_crit_section_ptr",
          "c_type": "undefined8 *"
        },
        {
          "original_name": "param_2",
          "new_name": "ai_value_to_set",
          "c_type": "undefined8"
        }
      ],
      "local_variables": [],
      "comments": [
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 90%] Calls `EnterCriticalSection` on `param_1 + 1`. This implies `param_1` points to a structure, and the `CRITICAL_SECTION` object itself starts at an offset of 8 bytes (size of one `undefined8`)."
        },
        {
          "address_offset_from_function_start": "0x1a",
          "text": "ai_[GUESS: 90%] Assigns `param_2` to `*param_1`. This might be setting a flag or a pointer within the structure `param_1` points to, indicating the owner or state while the critical section is held."
        }
      ],
      "global_data_references": [],
      "subcall_target_functions": [
        {
          "address": "180959440",
          "new_function_name": "ai_EnterCriticalSection",
          "demangle": False
        }
      ]
    },
    {
      "function_identification": {
        "address": "1806fc390"
      },
      "function_metadata": {
        "new_function_name": "ai_release_critical_section",
        "function_comment": "This function clears the first member of the critical section structure pointed to by `param_1` and then leaves the critical section. It's the counterpart to `ai_acquire_critical_section`, releasing the protected resource."
      },
      "parameters": [
        {
          "original_name": "param_1",
          "new_name": "ai_crit_section_ptr",
          "c_type": "undefined8 *"
        }
      ],
      "local_variables": [],
      "comments": [
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 90%] Sets `*param_1` to 0. This likely clears a flag or pointer that was set by `ai_acquire_critical_section`."
        },
        {
          "address_offset_from_function_start": "0xb",
          "text": "ai_[GUESS: 90%] Calls `LeaveCriticalSection` on `param_1 + 1`, releasing the critical section."
        }
      ],
      "global_data_references": [],
      "subcall_target_functions": [
        {
          "address": "180959438",
          "new_function_name": "ai_LeaveCriticalSection",
          "demangle": False
        }
      ]
    },
    {
      "function_identification": {
        "address": "1806fc4b0"
      },
      "function_metadata": {
        "new_function_name": "ai_wait_for_condition_or_tls",
        "function_comment": "This function interacts with Thread Local Storage (TLS) and then performs a conditional wait using `FUN_18072f8d0`. It first checks a byte at an offset from the TLS pointer, calling `__dyn_tls_on_demand_init` if necessary. It then saves a value from TLS, clears `*param_1`, calls `FUN_18072f8d0`, and finally restores the saved TLS value to `*param_1`. The return value indicates the success of `FUN_18072f8d0`."
      },
      "parameters": [
        {
          "original_name": "param_1",
          "new_name": "ai_thread_state_value_ptr",
          "c_type": "undefined8 *"
        },
        {
          "original_name": "param_2",
          "new_name": "ai_wait_condition",
          "c_type": "undefined8"
        }
      ],
      "local_variables": [
        {
          "original_name": "lVar1",
          "new_name": "ai_tls_base_address",
          "c_type": "long long",
          "offset": "0x0"
        },
        {
          "original_name": "uVar2",
          "new_name": "ai_saved_tls_value",
          "c_type": "undefined8",
          "offset": "0x8"
        },
        {
          "original_name": "iVar3",
          "new_name": "ai_subcall_result",
          "c_type": "int",
          "offset": "0x10"
        }
      ],
      "comments": [
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 90%] `lVar1` stores the base address of the current thread's TLS data. The `GS` segment register is typically used for TLS in x86-64."
        },
        {
          "address_offset_from_function_start": "0x8",
          "text": "ai_[GUESS: 80%] `uVar2` stores a value read from an offset within the TLS data, which is later restored."
        },
        {
          "address_offset_from_function_start": "0x10",
          "text": "ai_[GUESS: 90%] `iVar3` stores the integer result of `FUN_18072f8d0`."
        },
        {
          "address_offset_from_function_start": "0x10",
          "text": "ai_[GUESS: 90%] `lVar1` is initialized with the current thread's TLS pointer, adjusted by `_tls_index`. This is a common way to access thread-local storage data."
        },
        {
          "address_offset_from_function_start": "0x17",
          "text": "ai_[GUESS: 80%] Checks a byte at `lVar1 + 0x48`. This offset likely corresponds to a flag indicating whether the TLS data has been initialized."
        },
        {
          "address_offset_from_function_start": "0x1f",
          "text": "ai_[GUESS: 90%] If the byte at `lVar1 + 0x48` is false (0), calls `__dyn_tls_on_demand_init` to initialize the TLS. This ensures thread-local data is ready."
        },
        {
          "address_offset_from_function_start": "0x23",
          "text": "ai_[GUESS: 90%] `uVar2` is set to the value at `lVar1 + 0x20`. This value is saved to be restored later."
        },
        {
          "address_offset_from_function_start": "0x27",
          "text": "ai_[GUESS: 90%] Sets `*param_1` to 0. This might be clearing a flag or pointer before a wait operation."
        },
        {
          "address_offset_from_function_start": "0x2a",
          "text": "ai_[GUESS: 80%] Calls `FUN_18072f8d0` with `param_1 + 1` and `param_2`. This looks like a wait function on a condition variable or similar, with `param_1 + 1` possibly being the condition variable itself."
        },
        {
          "address_offset_from_function_start": "0x32",
          "text": "ai_[GUESS: 90%] Restores `uVar2` (the saved TLS value) to `*param_1`. This effectively reverts the change made earlier, possibly indicating the thread is no longer waiting."
        },
        {
          "address_offset_from_function_start": "0x35",
          "text": "ai_[GUESS: 90%] Returns true if `iVar3` (the result of `FUN_18072f8d0`) is non-zero, false otherwise."
        }
      ],
      "global_data_references": [
        {
          "address": "_tls_index",
          "new_name": "ai_tls_index",
          "c_type": "uint",
          "comment": "ai_Global variable that holds the index for thread-local storage."
        },
        {
          "address": "ThreadLocalStoragePointer",
          "new_name": "ai_thread_local_storage_pointer",
          "c_type": "void*",
          "comment": "ai_Base pointer for accessing thread-local storage."
        }
      ],
      "subcall_target_functions": [
        {
          "address": "__dyn_tls_on_demand_init",
          "new_function_name": "ai_dyn_tls_on_demand_init",
          "demangle": False
        },
        {
          "address": "18072f8d0",
          "new_function_name": "ai_wait_for_object_or_condition",
          "demangle": False
        }
      ]
    },
    {
      "function_identification": {
        "address": "18071f9c0"
      },
      "function_metadata": {
        "new_function_name": "ai_SafepointSynchronize__block",
        "function_comment": "This function checks if a global function pointer `DAT_180ccad88` is set. If it is, it calls the function pointed to by `DAT_180ccad88`. This indicates a mechanism for safepoint synchronization, where a registered callback function is executed to block threads at a safepoint."
      },
      "parameters": [],
      "local_variables": [],
      "comments": [
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 90%] Checks if the global function pointer `DAT_180ccad88` is not null. If it's null, no synchronization action is performed."
        },
        {
          "address_offset_from_function_start": "0xc",
          "text": "ai_[GUESS: 90%] If `DAT_180ccad88` is not null, the function it points to is called. This is the actual safepoint blocking mechanism."
        }
      ],
      "global_data_references": [
        {
          "address": "180ccad88",
          "new_name": "ai_safepoint_block_callback",
          "c_type": "code *",
          "comment": "ai_A global function pointer that, if set, is called to block threads during a safepoint operation."
        }
      ],
      "subcall_target_functions": []
    },
    {
      "function_identification": {
        "address": "180796000"
      },
      "function_metadata": {
        "new_function_name": "ai_VM_Operation__exit_safepoint",
        "function_comment": "This function manages the exit from a safepoint for a VM operation. It first asserts that the thread's state is `_thread_in_vm`. If not, it triggers an error handling path that involves printing debug information and an `INT3` instruction, likely for debugging or crash reporting. It then conditionally calls `FUN_180793520`, always calls `FUN_1807c2a70`, and then loops if `param_1 + 0x590` is non-zero and `FUN_1803dac00` returns true. Finally, it calls `FUN_1807960b0`.\n\nVulnerability: [VULN: 30%] Assert Failure Leading to Crash: The `guarantee(state == _thread_in_vm)` check is essentially an assertion. If `*(int *)(param_1 + 0x454)` is not 6, the code deliberately triggers an `INT3` instruction. While intended for debugging or controlled termination, in a production environment, this could be exploited as a denial-of-service vector if an attacker can manipulate the thread state."
      },
      "parameters": [
        {
          "original_name": "param_1",
          "new_name": "ai_thread_object",
          "c_type": "long long"
        },
        {
          "original_name": "param_2",
          "new_name": "ai_flag_one",
          "c_type": "undefined1"
        },
        {
          "original_name": "param_3",
          "new_name": "ai_flag_two",
          "c_type": "undefined1"
        }
      ],
      "local_variables": [
        {
          "original_name": "iVar1",
          "new_name": "ai_thread_state",
          "c_type": "int",
          "offset": "0x0"
        },
        {
          "original_name": "pcVar2",
          "new_name": "ai_debug_callback",
          "c_type": "code *",
          "offset": "0x4"
        },
        {
          "original_name": "cVar3",
          "new_name": "ai_loop_condition",
          "c_type": "char",
          "offset": "0xc"
        }
      ],
      "comments": [
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 90%] `iVar1` stores the current thread state from `param_1 + 0x454`."
        },
        {
          "address_offset_from_function_start": "0x4",
          "text": "ai_[GUESS: 70%] `pcVar2` will hold a function pointer for a debug/halt routine, obtained via `swi(3)`."
        },
        {
          "address_offset_from_function_start": "0xc",
          "text": "ai_[GUESS: 80%] `cVar3` stores the boolean result of `FUN_1803dac00`."
        },
        {
          "address_offset_from_function_start": "0x16",
          "text": "ai_[GUESS: 90%] The loop continues as long as `cVar3` (result of `FUN_1803dac00`) is not null (true)."
        },
        {
          "address_offset_from_function_start": "0x1b",
          "text": "ai_[GUESS: 90%] `iVar1` is assigned the value from `param_1 + 0x454`, which represents the current state of the thread."
        },
        {
          "address_offset_from_function_start": "0x21",
          "text": "ai_[GUESS: 90%] Checks if `iVar1` (thread state) is not equal to 6 (which is likely `_thread_in_vm`)."
        },
        {
          "address_offset_from_function_start": "0x24",
          "text": "ai_[GUESS: 90%] Dereferences `g_vm_state_indicator_ptr` and sets its value to `0x58`. This is likely updating a global VM state indicator."
        },
        {
          "address_offset_from_function_start": "0x28",
          "text": "ai_[GUESS: 90%] Calls `FUN_1802a9e40` with debugging information (source file, line, assertion message, and formatted message with the actual state). This suggests a logging or assertion failure handling function."
        },
        {
          "address_offset_from_function_start": "0x32",
          "text": "ai_[GUESS: 90%] `pcVar2` gets the address of a software interrupt (INT3) handler. This is a common way to trigger a debugger or a controlled crash in assertion failures."
        },
        {
          "address_offset_from_function_start": "0x37",
          "text": "ai_[GUESS: 90%] Calls the function pointed to by `pcVar2`, which will trigger the `INT3`."
        },
        {
          "address_offset_from_function_start": "0x3b",
          "text": "ai_[GUESS: 80%] If `DAT_180cc9fe0` is not zero, call `FUN_180793520` with `param_1`. This might be a specific debug or logging function."
        },
        {
          "address_offset_from_function_start": "0x40",
          "text": "ai_[GUESS: 90%] Calls `FUN_1807c2a70` with `param_1`. This seems to be another thread-state transition or cleanup function."
        },
        {
          "address_offset_from_function_start": "0x45",
          "text": "ai_[GUESS: 90%] Checks if the qword at `param_1 + 0x590` is zero. This could be a flag indicating pending operations or a state that requires further processing."
        },
        {
          "address_offset_from_function_start": "0x4b",
          "text": "ai_[GUESS: 80%] Calls `FUN_1803dac00` with `param_1 + 0x588`, `param_2`, and `param_3`. This is likely a function that performs an action and returns a status."
        },
        {
          "address_offset_from_function_start": "0x53",
          "text": "ai_[GUESS: 90%] Calls `FUN_1807960b0` with `param_1`. This is likely a final exit or post-safepoint processing routine."
        }
      ],
      "global_data_references": [
        {
          "address": "g_vm_state_indicator_ptr",
          "new_name": "ai_g_vm_state_indicator_ptr",
          "c_type": "byte *",
          "comment": "ai_A global pointer to a byte that indicates the current VM state."
        },
        {
          "address": "180cc9fe0",
          "new_name": "ai_global_debug_flag",
          "c_type": "uint",
          "comment": "ai_A global flag, possibly indicating a debug mode or a condition that bypasses certain operations."
        },
        {
          "address": "180aa9e30",
          "new_name": "ai_s_Illegal_threadstate_encountered_fmt",
          "c_type": "const char*",
          "comment": "ai_Format string for an error message indicating an illegal thread state."
        },
        {
          "address": "180aa9e58",
          "new_name": "ai_s_guarantee_state_thread_in_vm_failed_msg",
          "c_type": "const char*",
          "comment": "ai_Error message string for a failed assertion related to thread state."
        },
        {
          "address": "180aa9e88",
          "new_name": "ai_s_safepointMechanism_cpp_path",
          "c_type": "const char*",
          "comment": "ai_String representing the source file path where the assertion failed."
        }
      ],
      "subcall_target_functions": [
        {
          "address": "1802a9e40",
          "new_function_name": "ai_report_assertion_failure",
          "demangle": False
        },
        {
          "address": "180793520",
          "new_function_name": "ai_process_thread_event",
          "demangle": False
        },
        {
          "address": "1807c2a70",
          "new_function_name": "ai_notify_thread_state_change",
          "demangle": False
        },
        {
          "address": "1803dac00",
          "new_function_name": "ai_attempt_thread_transition",
          "demangle": False
        },
        {
          "address": "1807960b0",
          "new_function_name": "ai_thread_safepoint_post_processing",
          "demangle": False
        }
      ]
    },
    {
      "function_identification": {
        "address": "1807960b0"
      },
      "function_metadata": {
        "new_function_name": "ai_thread_safepoint_post_processing",
        "function_comment": "This function performs post-processing related to safepoints for a thread. It uses thread-local storage (TLS) to get a thread-specific pointer. The function has a `do-while` loop that continues until certain global flags (`DAT_180cc9fe0`) and thread-specific states (`param_1 + 0x590`) are cleared. Inside the loop, it conditionally logs messages ('Computed disarmed', 'Computed watermark', 'Computed armed') based on various global and thread-local conditions. It manipulates thread state values (`param_1 + 0x30` and `param_1 + 0x28`) and calls `SafepointSynchronize::block`.\n\nVulnerability: [VULN: 30%] Potential Infinite Loop: The `do-while` loop at the end (`while ((!bVar3) && ((DAT_180cc9fe0 != 0 || (*(longlong *)(param_1 + 0x590) != 0))));`) continues as long as `bVar3` is false AND either `DAT_180cc9fe0` is non-zero OR `*(longlong *)(param_1 + 0x590)` is non-zero. If these conditions are not properly cleared or if external factors prevent their state change, the loop could become infinite, leading to a denial-of-service."
      },
      "parameters": [
        {
          "original_name": "param_1",
          "new_name": "ai_thread_object",
          "c_type": "long long"
        }
      ],
      "local_variables": [
        {
          "original_name": "plVar1",
          "new_name": "ai_tls_thread_ptr",
          "c_type": "long long *",
          "offset": "0x0"
        },
        {
          "original_name": "lVar2",
          "new_name": "ai_current_tls_thread",
          "c_type": "long long",
          "offset": "0x8"
        },
        {
          "original_name": "bVar3",
          "new_name": "ai_is_armed_state",
          "c_type": "bool",
          "offset": "0x10"
        },
        {
          "original_name": "lVar4",
          "new_name": "ai_target_thread_state_value",
          "c_type": "long long",
          "offset": "0x18"
        },
        {
          "original_name": "uVar5",
          "new_name": "ai_target_thread_state_type",
          "c_type": "undefined8",
          "offset": "0x20"
        }
      ],
      "comments": [
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 90%] `plVar1` points to the thread-local storage for the current thread."
        },
        {
          "address_offset_from_function_start": "0x8",
          "text": "ai_[GUESS: 80%] `lVar2` holds a value from TLS, similar to `*plVar1`."
        },
        {
          "address_offset_from_function_start": "0x10",
          "text": "ai_[GUESS: 90%] `bVar3` is a boolean flag, likely indicating if the 'armed' state is active."
        },
        {
          "address_offset_from_function_start": "0x18",
          "text": "ai_[GUESS: 80%] `lVar4` holds a target thread state value, either from `DAT_180cca3e8` (disarmed) or `DAT_180cca3e0` (armed)."
        },
        {
          "address_offset_from_function_start": "0x20",
          "text": "ai_[GUESS: 80%] `uVar5` holds a target thread state type, either from `DAT_180cca3d8` (disarmed) or `DAT_180cca3d0` (armed)."
        },
        {
          "address_offset_from_function_start": "0x2e",
          "text": "ai_[GUESS: 90%] `plVar1` is initialized with the current thread's TLS pointer, adjusted by `_tls_index`."
        },
        {
          "address_offset_from_function_start": "0x36",
          "text": "ai_[GUESS: 90%] The `do-while` loop starts here, continuing until `bVar3` is true AND (`DAT_180cc9fe0` is zero AND `param_1 + 0x590` is zero)."
        },
        {
          "address_offset_from_function_start": "0x3e",
          "text": "ai_[GUESS: 90%] Checks if `DAT_180cc9fe0` is zero AND `param_1 + 0x590` is zero. This conditional block seems to handle the 'disarmed' state logic."
        },
        {
          "address_offset_from_function_start": "0x44",
          "text": "ai_[GUESS: 90%] `bVar3` is set to false, indicating the 'disarmed' state."
        },
        {
          "address_offset_from_function_start": "0x47",
          "text": "ai_[GUESS: 90%] Calls `FUN_1807c2970` with `param_1`. This function likely determines some internal state or performs a preliminary action."
        },
        {
          "address_offset_from_function_start": "0x4b",
          "text": "ai_[GUESS: 90%] `uVar5` is set to `DAT_180cca3d8` (disarmed type)."
        },
        {
          "address_offset_from_function_start": "0x51",
          "text": "ai_[GUESS: 90%] If `lVar4` (result of `FUN_1807c2970`) is zero, then set `lVar4` to `DAT_180cca3e8` (disarmed value)."
        },
        {
          "address_offset_from_function_start": "0x58",
          "text": "ai_[GUESS: 80%] If `DAT_180cca438` is not zero, then proceed with logging."
        },
        {
          "address_offset_from_function_start": "0x5b",
          "text": "ai_[GUESS: 90%] `lVar4` is updated with the current `*plVar1` (TLS thread pointer)."
        },
        {
          "address_offset_from_function_start": "0x60",
          "text": "ai_[GUESS: 90%] If the byte at `lVar4 + 0x48` is false, call `__dyn_tls_on_demand_init` for TLS initialization."
        },
        {
          "address_offset_from_function_start": "0x64",
          "text": "ai_[GUESS: 80%] Calls `FUN_180795ed0` with a format string and a value from TLS. This looks like a debug print statement: 'Computed disarmed for tid %d'."
        },
        {
          "address_offset_from_function_start": "0x70",
          "text": "ai_[GUESS: 90%] `lVar4` is re-set to `DAT_180cca3e8`."
        },
        {
          "address_offset_from_function_start": "0x72",
          "text": "ai_[GUESS: 80%] Else block: executed if `lVar4` (result of `FUN_1807c2970`) was not zero. This path handles the 'watermark' or similar state."
        },
        {
          "address_offset_from_function_start": "0x74",
          "text": "ai_[GUESS: 80%] If `DAT_180cca438` is not zero, then proceed with logging."
        },
        {
          "address_offset_from_function_start": "0x77",
          "text": "ai_[GUESS: 90%] `lVar2` is updated with the current `*plVar1` (TLS thread pointer)."
        },
        {
          "address_offset_from_function_start": "0x7c",
          "text": "ai_[GUESS: 90%] If the byte at `lVar2 + 0x48` is false, call `__dyn_tls_on_demand_init` for TLS initialization."
        },
        {
          "address_offset_from_function_start": "0x80",
          "text": "ai_[GUESS: 80%] Calls `FUN_180795ed0` with a format string and a value from TLS. This looks like a debug print statement: 'Computed watermark for tid %d'."
        },
        {
          "address_offset_from_function_start": "0x89",
          "text": "ai_[GUESS: 90%] Else block: executed if the initial `if` condition (`DAT_180cc9fe0 == 0 && *(longlong *)(param_1 + 0x590) == 0`) was false. This path likely handles the 'armed' state."
        },
        {
          "address_offset_from_function_start": "0x8b",
          "text": "ai_[GUESS: 90%] `bVar3` is set to true, indicating the 'armed' state."
        },
        {
          "address_offset_from_function_start": "0x8e",
          "text": "ai_[GUESS: 90%] Calls `FUN_1807c2970` with `param_1`."
        },
        {
          "address_offset_from_function_start": "0x92",
          "text": "ai_[GUESS: 90%] `uVar5` is set to `DAT_180cca3d0` (armed type)."
        },
        {
          "address_offset_from_function_start": "0x95",
          "text": "ai_[GUESS: 90%] `lVar4` is set to `DAT_180cca3e0` (armed value)."
        },
        {
          "address_offset_from_function_start": "0x9c",
          "text": "ai_[GUESS: 80%] If `DAT_180cca438` is not zero, then proceed with logging."
        },
        {
          "address_offset_from_function_start": "0x9f",
          "text": "ai_[GUESS: 90%] `lVar4` is updated with the current `*plVar1` (TLS thread pointer)."
        },
        {
          "address_offset_from_function_start": "0xa4",
          "text": "ai_[GUESS: 90%] If the byte at `lVar4 + 0x48` is false, call `__dyn_tls_on_demand_init` for TLS initialization."
        },
        {
          "address_offset_from_function_start": "0xa8",
          "text": "ai_[GUESS: 80%] Calls `FUN_180795ed0` with a format string and a value from TLS. This looks like a debug print statement: 'Computed armed for tid %d'."
        },
        {
          "address_offset_from_function_start": "0xae",
          "text": "ai_[GUESS: 90%] `lVar4` is re-set to `DAT_180cca3e0`."
        },
        {
          "address_offset_from_function_start": "0xb1",
          "text": "ai_[GUESS: 90%] Checks if `*(longlong *)(param_1 + 0x28)` is not equal to `lVar4` (target state value) OR `*(longlong *)(param_1 + 0x28)` is equal to `DAT_180cca3e0` (armed value). This indicates a state mismatch or if the thread is in the armed state."
        },
        {
          "address_offset_from_function_start": "0xba",
          "text": "ai_[GUESS: 80%] If the 2f bit (0x2000000000000000) of `DAT_180c85a80` is set, then proceed to the bad instruction halt."
        },
        {
          "address_offset_from_function_start": "0xbf",
          "text": "ai_[GUESS: 90%] Calls `halt_baddata()`. This is a placeholder for a bad instruction. It's likely a crash or an unexpected state."
        },
        {
          "address_offset_from_function_start": "0xc2",
          "text": "ai_[GUESS: 90%] Calls `cpuid_basic_info(0)`. This instruction is used to query CPU features. Its presence here might be for performance analysis or a sanity check."
        },
        {
          "address_offset_from_function_start": "0xc5",
          "text": "ai_[GUESS: 90%] Sets the qword at `param_1 + 0x30` to `uVar5` (the target state type)."
        },
        {
          "address_offset_from_function_start": "0xc9",
          "text": "ai_[GUESS: 90%] Sets the qword at `param_1 + 0x28` to `lVar4` (the target state value). These two assignments update the thread's state."
        },
        {
          "address_offset_from_function_start": "0xcd",
          "text": "ai_[GUESS: 90%] Calls `SafepointSynchronize::block()`, which will cause the thread to block if a safepoint is active."
        }
      ],
      "global_data_references": [
        {
          "address": "ThreadLocalStoragePointer",
          "new_name": "ai_thread_local_storage_pointer",
          "c_type": "void*",
          "comment": "ai_Base pointer for accessing thread-local storage."
        },
        {
          "address": "_tls_index",
          "new_name": "ai_tls_index",
          "c_type": "uint",
          "comment": "ai_Global variable that holds the index for thread-local storage."
        },
        {
          "address": "180cc9fe0",
          "new_name": "ai_global_debug_flag",
          "c_type": "uint",
          "comment": "ai_A global flag, possibly indicating a debug mode or a condition that bypasses certain operations."
        },
        {
          "address": "180cca3d8",
          "new_name": "ai_thread_state_disarmed_type",
          "c_type": "undefined8",
          "comment": "ai_A global value representing the 'disarmed' state type for a thread."
        },
        {
          "address": "180cca3e8",
          "new_name": "ai_thread_state_disarmed_value",
          "c_type": "long long",
          "comment": "ai_A global value representing the 'disarmed' state value for a thread."
        },
        {
          "address": "180cca438",
          "new_name": "ai_logging_enabled_flag",
          "c_type": "int",
          "comment": "ai_A global flag indicating whether logging is enabled for this module."
        },
        {
          "address": "180aa9df0",
          "new_name": "ai_s_Computed_disarmed_for_tid_fmt",
          "c_type": "const char*",
          "comment": "ai_Format string for logging the 'disarmed' state of a thread."
        },
        {
          "address": "180aa9e10",
          "new_name": "ai_s_Computed_watermark_for_tid_fmt",
          "c_type": "const char*",
          "comment": "ai_Format string for logging the 'watermark' state of a thread."
        },
        {
          "address": "180cca3d0",
          "new_name": "ai_thread_state_armed_type",
          "c_type": "undefined8",
          "comment": "ai_A global value representing the 'armed' state type for a thread."
        },
        {
          "address": "180cca3e0",
          "new_name": "ai_thread_state_armed_value",
          "c_type": "long long",
          "comment": "ai_A global value representing the 'armed' state value for a thread."
        },
        {
          "address": "180aa9dd0",
          "new_name": "ai_s_Computed_armed_for_tid_fmt",
          "c_type": "const char*",
          "comment": "ai_Format string for logging the 'armed' state of a thread."
        },
        {
          "address": "180c85a80",
          "new_name": "ai_global_control_flag",
          "c_type": "long long",
          "comment": "ai_A global control flag, used for conditional execution paths, possibly related to system features or debug options."
        }
      ],
      "subcall_target_functions": [
        {
          "address": "__dyn_tls_on_demand_init",
          "new_function_name": "ai_dyn_tls_on_demand_init",
          "demangle": False
        },
        {
          "address": "1807c2970",
          "new_function_name": "ai_get_thread_safepoint_state",
          "demangle": False
        },
        {
          "address": "180795ed0",
          "new_function_name": "ai_log_thread_state",
          "demangle": False
        },
        {
          "address": "halt_baddata",
          "new_function_name": "ai_halt_baddata",
          "demangle": False
        },
        {
          "address": "cpuid_basic_info",
          "new_function_name": "ai_cpuid_basic_info",
          "demangle": False
        },
        {
          "address": "18071f9c0",
          "new_function_name": "ai_SafepointSynchronize__block",
          "demangle": False
        }
      ]
    },
    {
      "function_identification": {
        "address": "1807b5dc0"
      },
      "function_metadata": {
        "new_function_name": "ai_initialize_thread_perf_data",
        "function_comment": "This function initializes a structure pointed to by `param_1` with various input parameters. It sets the first three 8-byte members to zero. It then conditionally sets one of the dwords based on `DAT_180cc5398` and finally sets two other dwords. This seems to be initializing performance or timing-related data for a thread."
      },
      "parameters": [
        {
          "original_name": "param_1",
          "new_name": "ai_thread_data_ptr",
          "c_type": "undefined8 *"
        },
        {
          "original_name": "param_2",
          "new_name": "ai_initial_value_if_not_one",
          "c_type": "undefined4"
        },
        {
          "original_name": "param_3",
          "new_name": "ai_offset_1c_value",
          "c_type": "undefined4"
        },
        {
          "original_name": "param_4",
          "new_name": "ai_offset_20_value",
          "c_type": "undefined4"
        }
      ],
      "local_variables": [
        {
          "original_name": "uVar1",
          "new_name": "ai_conditional_value",
          "c_type": "undefined4",
          "offset": "0x0"
        },
        {
          "original_name": "bVar2",
          "new_name": "ai_check_flag_result",
          "c_type": "bool",
          "offset": "0x4"
        }
      ],
      "comments": [
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 80%] `uVar1` stores a value that is conditionally set based on `bVar2`."
        },
        {
          "address_offset_from_function_start": "0x4",
          "text": "ai_[GUESS: 90%] `bVar2` is a boolean, true if `DAT_180cc5398` is not equal to 1."
        },
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 90%] Sets the first 3 qwords (24 bytes) of the structure pointed to by `param_1` to zero. This clears initial state or counters."
        },
        {
          "address_offset_from_function_start": "0x1d",
          "text": "ai_[GUESS: 90%] `bVar2` is set to true if `DAT_180cc5398` is not 1, and false otherwise. This global flag might control initialization behavior."
        },
        {
          "address_offset_from_function_start": "0x24",
          "text": "ai_[GUESS: 90%] Sets the dword at `param_1 + 0x1c` to `param_3`."
        },
        {
          "address_offset_from_function_start": "0x28",
          "text": "ai_[GUESS: 90%] If `bVar2` is true, `uVar1` is set to `param_2`; otherwise, it remains 0. This conditionally initializes a field."
        },
        {
          "address_offset_from_function_start": "0x2c",
          "text": "ai_[GUESS: 90%] Sets the dword at `param_1 + 0x20` to `param_4`."
        },
        {
          "address_offset_from_function_start": "0x30",
          "text": "ai_[GUESS: 90%] Sets the dword at `param_1 + 0x18` to `uVar1`."
        },
        {
          "address_offset_from_function_start": "0x33",
          "text": "ai_[GUESS: 90%] Returns the original `param_1` pointer."
        }
      ],
      "global_data_references": [
        {
          "address": "180cc5398",
          "new_name": "ai_global_state_flag_one",
          "c_type": "uint",
          "comment": "ai_A global flag or counter, likely indicating a system-wide state or a specific mode of operation. Controls conditional initialization in this function."
        }
      ],
      "subcall_target_functions": []
    },
    {
      "function_identification": {
        "address": "1807b5df0"
      },
      "function_metadata": {
        "new_function_name": "ai_measure_thread_activity",
        "function_comment": "This function appears to measure thread activity or performance metrics. It first checks if a counter (`param_1 + 0x14`) is less than a limit (`param_1 + 0x1c`). If so, it increments the counter and yields control to another thread via `SwitchToThread`. Otherwise, it captures two timestamps/counters using `FUN_180888680`, calls `FUN_18072bf10` with `param_1[4]`, and then updates two members of `param_1` (`*param_1` and `param_1[1]`) with the difference between new and old timestamps. This suggests it's accumulating time or work done by the thread."
      },
      "parameters": [
        {
          "original_name": "param_1",
          "new_name": "ai_thread_perf_data",
          "c_type": "long long *"
        }
      ],
      "local_variables": [
        {
          "original_name": "lVar1",
          "new_name": "ai_current_timestamp_high",
          "c_type": "long long",
          "offset": "0x0"
        },
        {
          "original_name": "plVar2",
          "new_name": "ai_timestamp_return_ptr",
          "c_type": "long long *",
          "offset": "0x8"
        },
        {
          "original_name": "local_28",
          "new_name": "ai_initial_timestamp_low",
          "c_type": "long long",
          "offset": "-0x28"
        },
        {
          "original_name": "lStack_20",
          "new_name": "ai_initial_timestamp_high",
          "c_type": "long long",
          "offset": "-0x20"
        },
        {
          "original_name": "local_18",
          "new_name": "ai_current_timestamp_buffer",
          "c_type": "undefined1[16]",
          "offset": "-0x18"
        }
      ],
      "comments": [
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 80%] `lVar1` stores the high part of a timestamp or counter."
        },
        {
          "address_offset_from_function_start": "0x8",
          "text": "ai_[GUESS: 70%] `plVar2` is a pointer used to capture multiple return values from `FUN_180888680`."
        },
        {
          "address_offset_from_function_start": "0x18",
          "text": "ai_[GUESS: 80%] `local_28` stores the low part of the initial timestamp."
        },
        {
          "address_offset_from_function_start": "0x20",
          "text": "ai_[GUESS: 80%] `lStack_20` stores the high part of the initial timestamp."
        },
        {
          "address_offset_from_function_start": "0x28",
          "text": "ai_[GUESS: 90%] `local_18` is a 16-byte buffer used to receive the timestamp/counter values from `FUN_180888680`."
        },
        {
          "address_offset_from_function_start": "0x0",
          "text": "ai_[GUESS: 90%] Checks if the dword at `param_1 + 0x14` is less than the dword at `param_1 + 0x1c`. These offsets likely represent a current count and a maximum limit."
        },
        {
          "address_offset_from_function_start": "0x8",
          "text": "ai_[GUESS: 90%] If the condition is true, increment the dword at `param_1 + 0x14`."
        },
        {
          "address_offset_from_function_start": "0x10",
          "text": "ai_[GUESS: 90%] Calls `SwitchToThread()`, yielding the current thread's execution time slice. This is typically done to prevent a single thread from monopolizing the CPU."
        },
        {
          "address_offset_from_function_start": "0x16",
          "text": "ai_[GUESS: 90%] If the initial `if` condition is false, `FUN_180888680` is called to get a timestamp or a pair of counter values. These values are stored in `local_28` and `lStack_20`."
        },
        {
          "address_offset_from_function_start": "0x20",
          "text": "ai_[GUESS: 90%] `local_28` is set to the first 8 bytes returned by `FUN_180888680`."
        },
        {
          "address_offset_from_function_start": "0x23",
          "text": "ai_[GUESS: 90%] `lStack_20` is set to the second 8 bytes returned by `FUN_180888680`."
        },
        {
          "address_offset_from_function_start": "0x26",
          "text": "ai_[GUESS: 90%] Calls `FUN_18072bf10` with the integer value of `param_1[4]`. This function likely processes or uses a specific metric from the thread data."
        },
        {
          "address_offset_from_function_start": "0x2c",
          "text": "ai_[GUESS: 90%] `FUN_180888680` is called again to get current timestamp/counter values, stored in `local_18`."
        },
        {
          "address_offset_from_function_start": "0x32",
          "text": "ai_[GUESS: 90%] `lVar1` is set to the second 8 bytes returned by `FUN_180888680`."
        },
        {
          "address_offset_from_function_start": "0x35",
          "text": "ai_[GUESS: 90%] `*param_1` is updated by adding the difference between the current first timestamp/counter value and `local_28` (the initial first value). This is accumulating a delta."
        },
        {
          "address_offset_from_function_start": "0x39",
          "text": "ai_[GUESS: 90%] `param_1[1]` is updated by adding the difference between `lVar1` (current second value) and `lStack_20` (initial second value). This is accumulating another delta."
        }
      ],
      "global_data_references": [],
      "subcall_target_functions": [
        {
          "address": "SwitchToThread",
          "new_function_name": "ai_SwitchToThread",
          "demangle": False
        },
        {
          "address": "180888680",
          "new_function_name": "ai_get_performance_counter",
          "demangle": False
        },
        {
          "address": "18072bf10",
          "new_function_name": "ai_process_thread_metric",
          "demangle": False
        }
      ]
    }
  ]
}



# --- CONFIGURATION OPTIONS ---
# Set to True to enable type casting for parameters, local variables, and global data.
# Set to False to skip all type casting operations and only apply names/comments.
GLOBAL_ENABLE_TYPE_CASTING = True

# Global variable to store the program's pointer size, initialized in main script logic
program_pointer_size = 8 # Default to 8 for 64-bit, but will be overridden

# Global cache for newly defined types to help get_or_create_datatype find them quickly
_script_defined_datatypes_cache = {}

# Helper for printing messages with indentation
def print_indented(level, message):
    print("  " * level + message)

def printerr(message):
    print_indented(1, "[ERROR] " + message)

# --- Helper function to get or create DataType ---
# (PASTE YOUR get_or_create_datatype FUNCTION HERE)
def get_or_create_datatype(type_name, data_type_manager):
    # ... (content of get_or_create_datatype) ...
    if not type_name:
        return None

    cached_dt = _script_defined_datatypes_cache.get(type_name)
    if cached_dt:
        return cached_dt

    if type_name == "void":
        return VoidDataType.dataType

    dt = data_type_manager.getDataType(type_name)
    if dt:
        return dt

    if type_name == "uint" or type_name == "unsigned int":
        return UnsignedIntegerDataType.dataType
    if type_name == "bool" or type_name == "_Bool":
        return BooleanDataType.dataType
    if type_name == "int" or type_name == "signed int":
        return IntegerDataType.dataType
    if type_name == "longlong" or type_name == "long long":
        return LongLongDataType.dataType
    
    if '[' in type_name and ']' in type_name:
        try:
            base_type_str, array_size_str = type_name.split('[')
            array_size = int(array_size_str.rstrip(']'))
            base_dt = get_or_create_datatype(base_type_str.strip(), data_type_manager)
            if base_dt:
                return ArrayDataType(base_dt, array_size, base_dt.getLength())
        except Exception as e:
            printerr("  [WARNING] Could not parse array type '{0}': {1}. Skipping array creation.".format(type_name, e))
            return None

    if type_name == "void*":
        return PointerDataType(VoidDataType.dataType, program_pointer_size) 

    if type_name.startswith("undefined"):
        if type_name[9:].isdigit():
            size = int(type_name[9:])
            undefined_dt = data_type_manager.getDataType("/Undefined/undefined{}".format(size))
            if undefined_dt:
                return undefined_dt
            
        undefined_dt = data_type_manager.getDataType("/Undefined/undefined")
        if undefined_dt:
            print_indented(2, "[WARNING] Specific undefined type '{0}' not found. Using generic '/Undefined/undefined'.".format(type_name))
            return undefined_dt
        
        print_indented(2, "[WARNING] Neither specific undefined type '{0}' nor generic '/Undefined/undefined' found. Using '/byte'.".format(type_name))
        return data_type_manager.getDataType("/byte")


    if type_name.endswith("*"):
        base_type_name = type_name[:-1].strip()
        base_dt = data_type_manager.getDataType(base_type_name)
        if base_dt:
            return PointerDataType(base_dt, program_pointer_size)
        else:
            cached_base_dt = _script_defined_datatypes_cache.get(base_type_name)
            if cached_base_dt:
                return PointerDataType(cached_base_dt, program_pointer_size)
            
            print_indented(2, "[WARNING] Base type '{0}' for pointer '{1}' not found in Data Type Manager or cache. Using 'void*'.".format(base_type_name, type_name))
            return PointerDataType(VoidDataType.dataType, program_pointer_size)
    
    printerr("  Data type '{0}' not found and cannot be inferred. Returning None.".format(type_name))
    return None

# --- Helper function for demangling ---
# (PASTE YOUR apply_demangled_name FUNCTION HERE)
def apply_demangled_name(address, new_name):
    # ... (content of apply_demangled_name) ...
    try:
        demangler = Demangler()
        demangler_options = DemanglerOptions()
        
        demangled_obj = demangler.demangle(new_name, demangler_options)
        
        if demangled_obj and demangled_obj.getDemangledName():
            ghidra_name = demangled_obj.getDemangledName()
            print_indented(2, "Demangled '{0}' to '{1}'".format(new_name, ghidra_name))
        else:
            ghidra_name = new_name
            
        return ghidra_name
    except Exception as e:
        print_indented(2, "[WARNING] Error during demangling for '{0}': {1}. Using name as is.".format(new_name, e))
        return new_name

# --- Functions for Type Definitions ---
# (PASTE YOUR define_typedefs FUNCTION HERE)
def define_typedefs(typedef_defs, data_type_manager):
    # ... (content of define_typedefs) ...
    print("\n--- Defining Typedefs ---")
    
    root_category_path = CategoryPath("/")

    for td_def in typedef_defs:
        name = td_def.get("name")
        base_type_str = td_def.get("base_type")
        comment = td_def.get("comment")

        if not name or not base_type_str:
            printerr("Skipping typedef entry due to missing 'name' or 'base_type': {0}".format(td_def))
            continue

        existing_dt = data_type_manager.getDataType(name)
        if existing_dt and isinstance(existing_dt, TypedefDataType):
            print_indented(1, "Typedef '{0}' already exists. Skipping.".format(name))
            _script_defined_datatypes_cache[name] = existing_dt
            continue

        base_dt = get_or_create_datatype(base_type_str, data_type_manager)
        if base_dt:
            try:
                new_typedef = TypedefDataType(root_category_path, name, base_dt)
                final_typedef_dt = data_type_manager.addDataType(new_typedef, None)
                _script_defined_datatypes_cache[name] = final_typedef_dt
                print_indented(1, "Defined typedef '{0}' as alias for '{1}'".format(name, base_type_str))
            except Exception as e:
                printerr("Error defining typedef '{0}': {1}".format(name, e))
        else:
            printerr("Base type '{0}' for typedef '{1}' could not be resolved. Skipping.".format(base_type_str, name))

# (PASTE YOUR define_structs FUNCTION HERE)
def define_structs(struct_defs, data_type_manager):
    # ... (content of define_structs) ...
    print("\n--- Defining Structs ---")

    root_category_path = CategoryPath("/")

    for struct_def in struct_defs:
        name = struct_def.get("name")
        members = struct_def.get("members", [])
        comment = struct_def.get("comment")

        if not name:
            printerr("Skipping struct entry due to missing 'name': {0}".format(struct_def))
            continue

        existing_dt = data_type_manager.getDataType(name)
        struct = None

        if existing_dt and isinstance(existing_dt, Structure):
            print_indented(1, "Struct '{0}' already exists. Attempting to update members.".format(name))
            struct = existing_dt
            try:
                struct.deleteAll()
                print_indented(2, "Cleared existing members of struct '{0}'.".format(name))
            except Exception as e:
                printerr("  Error clearing members of struct '{0}': {1}. Recreating.".format(name, e))
                struct = StructureDataType(root_category_path, name, 0)
        else:
            struct = StructureDataType(root_category_path, name, 0)
            print_indented(1, "Creating new struct '{0}'".format(name))
            
        for member_def in members:
            member_name = member_def.get("name")
            member_type_str = member_def.get("type")
            member_offset_str = member_def.get("offset")
            member_comment = member_def.get("comment")

            if not member_name or not member_type_str:
                printerr("    Skipping member entry due to missing 'name' or 'type': {0}".format(member_def))
                continue

            member_dt = get_or_create_datatype(member_type_str, data_type_manager)
            if member_dt:
                try:
                    offset = -1
                    if member_offset_str:
                        offset = int(member_offset_str, 16)
                    
                    if offset != -1:
                        struct.insertAtOffset(offset, member_dt, member_dt.getLength(), member_name, member_comment)
                        print_indented(2, "Added member '{0}' ({1}) at offset {2} to '{3}'".format(member_name, member_type_str, hex(offset), name))
                    else:
                        struct.add(member_dt, member_name, member_comment)
                        print_indented(2, "Added member '{0}' ({1}) to '{3}'".format(member_name, member_type_str, name))

                except Exception as e:
                    printerr("    Error adding member '{0}' to struct '{1}': {2}".format(member_name, name, e))
            else:
                printerr("    Data type '{0}' for member '{1}' of struct '{2}' could not be resolved. Skipping member.".format(member_type_str, member_name, name))
        
        try:
            final_struct_dt = data_type_manager.addDataType(struct, None)
            _script_defined_datatypes_cache[name] = final_struct_dt

            if comment:
                final_struct_dt.setComment(comment)
                print_indented(1, "Added comment for struct '{0}'".format(name))
            print_indented(1, "Successfully defined struct '{0}' with size {1}.".format(name, final_struct_dt.getLength() if final_struct_dt else "N/A"))
        except Exception as e:
            printerr("  Error finalizing struct '{0}' definition: {1}".format(name, e))

# Helper for variable count (PASTE YOUR get_variable_count FUNCTION HERE)
def get_variable_count(func):
    return len(func.getAllVariables())

def commitLocalNamesandParams(current_function):
    print_indented(1, "Attempting to commit local names and params for function: {}".format(current_function.getName()))
    decompiler = DecompInterface()
    decompiler.openProgram(currentProgram)
    
    # Decompile the function with a default timeout of 0 (no timeout)
    results = decompiler.decompileFunction(current_function, 0, monitor)

    if results.decompileCompleted():
        high_function = results.getHighFunction()
        if high_function is not None:
            # Start a transaction to ensure atomic database changes
            transaction_id = currentProgram.startTransaction("Commit Decompiler Local Names and Params")
            try:
                # Commit the local names from the HighFunction (decompiler's view) to the database
                # using SourceType.USER_DEFINED to mark them as user-defined, which Ghidra
                # will prioritize over auto-analysis.
                HighFunctionDBUtil.commitLocalNamesToDatabase(high_function, SourceType.USER_DEFINED)
                HighFunctionDBUtil.commitParamsToDatabase(high_function, True, ReturnCommitOption.COMMIT, SourceType.USER_DEFINED) 
                print_indented(1, "Successfully committed local names and params for function: {}".format(current_function.getName()))
            except Exception as e:
                printerr("An error occurred while committing names: {}".format(e))
            finally:
                # End the transaction, committing changes (True) or rolling back (False)
                currentProgram.endTransaction(transaction_id, True)
        else:
            printerr("Failed to get HighFunction for {}. Decompilation might have failed partially.".format(current_function.getName()))
    else:
        printerr("Decompilation did not complete successfully for {}. Status: {}".format(current_function.getName(), results.get,'status'))
        
    # Always dispose the decompiler interface
    decompiler.dispose()

# --- Main Script Logic ---
def apply_analysis_from_json_string(json_string_data):
    global program_pointer_size
    program = getCurrentProgram()
    if not program:
        printerr("No program open.")
        return

    program_pointer_size = program.getDefaultPointerSize() # Correct way to get pointer size

    data_type_manager = program.getDataTypeManager()
    symbol_table = program.getSymbolTable()
    listing = program.getListing()

    if type(json_string_data) == str:
        try:
            analysis_data = json.loads(json_string_data)
        except Exception as e:
            printerr("Error parsing inline JSON data: {0}".format(e))
            return
    elif type(json_string_data) == dict:
        analysis_data = json_string_data

    # Start a top-level transaction for type definitions (structs, typedefs)
    overall_transaction_id = program.startTransaction("Apply Type Definitions from JSON")
    try:
        # 0. Define Typedefs
        typedef_defs = analysis_data.get("typedef_definitions", [])
        define_typedefs(typedef_defs, data_type_manager) # THIS CALL IS NOW VALID

        # 0. Define Structs
        struct_defs = analysis_data.get("struct_definitions", [])
        define_structs(struct_defs, data_type_manager) # THIS CALL IS NOW VALID

    finally:
        program.endTransaction(overall_transaction_id, True) # Always commit type definitions

    # Now, process function updates, each in its own transaction for potential rollback
    print("\n--- Processing Function Updates ---")
    if "function_updates" not in analysis_data or not isinstance(analysis_data["function_updates"], list):
        printerr("JSON data missing 'function_updates' key or it's not a list. Skipping function updates.")
    else:
        for func_entry in analysis_data["function_updates"]:
            func_id = func_entry.get("function_identification", {})
            func_addr_str = func_id.get("address")
            
            if not func_addr_str:
                printerr("Skipping function entry: 'address' is missing from 'function_identification'.")
                continue

            try:
                function_address = program.getAddressFactory().getAddress(func_addr_str)
            except Exception as e:
                printerr("  Invalid function address '{0}': {1}. Skipping.".format(func_addr_str, e))
                continue

            function = program.getFunctionManager().getFunctionAt(function_address)
            if not function:
                continue
                # print_indented(1, "[INFO] Function at {0} not found. Attempting to create one.".format(function_address))
                # try:
                #     # Ghidra's createFunction is a global helper in scripts
                #     function = createFunction(function_address, None)
                #     if not function:
                #         printerr("  Failed to create function at address: {0}. Skipping.".format(function_address))
                #         continue
                #     print_indented(1, "Created new function at {0}".format(function_address))
                # except Exception as e:
                #     printerr("  Error creating function at {0}: {1}. Skipping.".format(function_address, e))
                #     continue

            print("\n--- Processing Function: {0} at {1} ---".format(function.getName(), function.getEntryPoint()))

            commitLocalNamesandParams(function)

            # Get initial variable count before any changes for this function
            initial_var_count = get_variable_count(function)
            print_indented(1, "Initial variable count: {0}".format(initial_var_count))

            # --- ATTEMPT 1: Apply with GLOBAL_ENABLE_TYPE_CASTING ---
            print_indented(1, "Attempting to apply markup with type casting enabled (GLOBAL_ENABLE_TYPE_CASTING={})...".format(GLOBAL_ENABLE_TYPE_CASTING))
            current_transaction_id = -1 # Initialize to an invalid ID
            
            try:
                current_transaction_id = program.startTransaction("Markup Function {0} (with casting)".format(function.getName()))
                
                # Apply function metadata (name and comment)
                func_metadata = func_entry.get("function_metadata", {})
                new_func_name = func_metadata.get("new_function_name")
                func_comment = func_metadata.get("function_comment")

                if new_func_name:
                    original_name = function.getName()
                    namespace = None

                    # Check if the original name has a namespace (e.g., "Namespace::FunctionName" or "Class::FunctionName")
                    if "::" in original_name:
                        # Get everything before the last "::"
                        namespace = original_name.rsplit("::", 1)[0]
                    
                    # Construct the final function name, preserving the namespace
                    if namespace:
                        # Combine the existing namespace with the new base name
                        if new_func_name.startswith(namespace + "::"):
                            final_func_name_with_namespace = new_func_name
                        else:
                            final_func_name_with_namespace = namespace + "::" + new_func_name
                    else:
                        # No original namespace, so just use the new_func_name
                        final_func_name_with_namespace = new_func_name

                    # Now, apply demangling to this name (if apply_demangled_name handles full names)
                    # Or, if apply_demangled_name is meant to only demangle the base, you might skip it here
                    # and ensure new_func_name is already demangled or handle demangling of the full name
                    final_func_name = apply_demangled_name(function.getEntryPoint(), final_func_name_with_namespace) 
                    
                    if final_func_name != original_name: # Compare against the original name
                        try:
                            function.setName(final_func_name, SourceType.USER_DEFINED)
                            print_indented(2, "Renamed function to '{0}'".format(final_func_name))
                        except Exception as e:
                            printerr("  Error renaming function '{0}' to '{1}': {2}".format(original_name, final_func_name, e))


                if func_comment:
                    try:
                        function.setComment(func_comment)
                        print_indented(2, "Added function comment.")
                    except Exception as e:
                        printerr("  Error adding function comment: {0}".format(e))
                
                # Update function signature (return type and parameters)
                return_type_str = func_entry.get("return_type") # Assuming return_type is directly in func_entry for simplicity
                if not return_type_str: # Default to void if not specified
                    return_type_str = "bool" # Changed to bool based on JSON return type

                return_dt = get_or_create_datatype(return_type_str, data_type_manager)
                
                # Ensure return_dt is not None before proceeding
                if not return_dt:
                    printerr("    [FATAL] Could not resolve return type '{0}' for function '{1}'. Falling back to default 'void' type directly.".format(return_type_str, function.getName()))
                    return_dt = VoidDataType.dataType # Direct fallback to ensure it's a valid object
                    if not return_dt: # This literally should not happen if Ghidra is running correctly
                        printerr("    [CRITICAL ERROR] Failed to even obtain VoidDataType.dataType. Skipping function processing.")
                        continue # Continue to the next function entry

                # --- Apply Parameters ---
                parameters_to_process = func_entry.get("parameters", [])
                
                for param_entry in parameters_to_process:
                    original_name = param_entry.get("original_name")
                    p_name = param_entry.get("new_name")
                    p_type_str = param_entry.get("c_type")

                    found_param = None
                    for p in function.getParameters():
                        if p.getName() == original_name:
                            found_param = p
                            break
                    
                    if found_param and p_name != found_param.getName():
                        try:
                            found_param.setName(p_name, SourceType.USER_DEFINED)
                            print_indented(3, "Renamed parameter '{0}' to '{1}'.".format(original_name, p_name))
                        except Exception as e:
                            printerr("    Error renaming parameter '{0}' to '{1}': {2}".format(original_name, p_name, e))

                        if GLOBAL_ENABLE_TYPE_CASTING:
                            p_dt = get_or_create_datatype(p_type_str, data_type_manager)
                            if p_dt:
                                current_var_dt = found_param.getDataType()
                                current_var_length = current_var_dt.getLength()
                                p_dt_length = p_dt.getLength()

                                # Perform length checks as in your reference code
                                if p_dt_length == -1:
                                    print_indented(4, "[WARNING] Target data type '{0}' has unknown length (-1). Skipping width check.".format(p_type_str))
                                elif current_var_length == -1:
                                    print_indented(4, "[WARNING] Current parameter '{0}' data type has unknown length (-1). Skipping width check.".format(p_name))
                                elif p_dt_length != current_var_length:
                                    printerr("    Width mismatch for parameter '{0}'. Desired type '{1}' (size {2}) does NOT match current type '{3}' (size {4}). Skipping type application.".format(
                                        p_name, p_type_str, p_dt_length, current_var_dt.getName(), current_var_length))
                                    # Continue to next variable if there's a width mismatch and we decided to skip
                                    continue 
                                
                                # Only set the data type if it's different from the current one
                                if not current_var_dt.isEquivalent(p_dt): # Using isEquivalent for robust comparison
                                    try:
                                        found_param.setDataType(p_dt, SourceType.USER_DEFINED)
                                        print_indented(3, "  Applied type '{0}' to parameter '{1}'.".format(p_type_str, p_name))
                                    except Exception as e:
                                        printerr("    Error applying type '{0}' to parameter '{1}': {2}".format(p_type_str, p_name, e))
                                else:
                                    print_indented(3, "  Data type for '{0}' is already equivalent to '{1}'. No change needed.".format(p_name, p_type_str))
                            else:
                                print_indented(3, "  Skipping type application for parameter '{0}': Type '{1}' could not be resolved.".format(p_name, p_type_str))
                    else:
                        # This occurs if `original_name` (e.g., 'uVar1', 'local_res10') was not found
                        # in Ghidra's `function.getLocalVariables()` map after clearing.
                        print_indented(2, "[INFO] Parameter '{0}' (intended as '{1}') not found in Ghidra's current parameters for function {2}. This might mean Ghidra optimized it away, it was identified differently, or it's a decompiler-only pseudo-variable.".format(
                            original_name, p_name, function.getName()))
                                
                # --- Apply local variables ---
                local_vars_to_process = func_entry.get("local_variables", [])

                # After clearing, we need to re-map Ghidra's current local variables.
                # Ghidra will typically re-populate these after a clear.
                # We map them by their current name (which would be the 'original_name' from JSON if it was recognized).
                current_ghidra_local_vars = function.getLocalVariables()
                ghidra_local_var_map = {lv.getName(): lv for lv in current_ghidra_local_vars}

                print_indented(1, "Processing local variables from JSON...")

                for var_entry in local_vars_to_process:
                    original_name = var_entry.get("original_name")
                    new_name = var_entry.get("new_name")
                    c_type_str = var_entry.get("c_type")
                    # Offset is present in your JSON but not used in the reference code for lookup,
                    # so we'll omit it from the lookup logic to match your working example.
                    # offset_str = var_entry.get("offset") 

                    if not original_name or not new_name:
                        printerr("      Skipping local variable entry due to missing 'original_name' or 'new_name': {0}".format(var_entry))
                        continue

                    # Try to get the Ghidra Variable object using its 'original_name'
                    local_var = ghidra_local_var_map.get(original_name)
                    
                    if local_var:
                        # If a Ghidra Variable object matching the original_name was found
                        print_indented(3, "Found Ghidra variable '{0}' for JSON entry '{1}'.".format(original_name, new_name))

                        # 1. Rename the local variable
                        if new_name != local_var.getName():
                            try:
                                local_var.setName(new_name, SourceType.USER_DEFINED)
                                print_indented(3, "  Renamed local variable '{0}' to '{1}'.".format(original_name, new_name))
                            except Exception as e:
                                printerr("    Error renaming local variable '{0}' to '{1}': {2}".format(original_name, new_name, e))

                        # 2. Apply the data type, if type casting is enabled and a C type is provided
                        if GLOBAL_ENABLE_TYPE_CASTING and c_type_str:
                            target_dt = get_or_create_datatype(c_type_str, data_type_manager)
                            if target_dt:
                                current_var_dt = local_var.getDataType()
                                current_var_length = current_var_dt.getLength()
                                target_dt_length = target_dt.getLength()

                                # Perform length checks as in your reference code
                                if target_dt_length == -1:
                                    print_indented(4, "[WARNING] Target data type '{0}' has unknown length (-1). Skipping width check.".format(c_type_str))
                                elif current_var_length == -1:
                                    print_indented(4, "[WARNING] Current local variable '{0}' data type has unknown length (-1). Skipping width check.".format(new_name))
                                elif target_dt_length != current_var_length:
                                    printerr("    Width mismatch for local variable '{0}'. Desired type '{1}' (size {2}) does NOT match current type '{3}' (size {4}). Skipping type application.".format(
                                        new_name, c_type_str, target_dt_length, current_var_dt.getName(), current_var_length))
                                    # Continue to next variable if there's a width mismatch and we decided to skip
                                    continue 
                                
                                # Only set the data type if it's different from the current one
                                if not current_var_dt.isEquivalent(target_dt): # Using isEquivalent for robust comparison
                                    try:
                                        local_var.setDataType(target_dt, SourceType.USER_DEFINED)
                                        print_indented(3, "  Applied type '{0}' to local variable '{1}'.".format(c_type_str, new_name))
                                    except Exception as e:
                                        printerr("    Error applying type '{0}' to local variable '{1}': {2}".format(c_type_str, new_name, e))
                                else:
                                    print_indented(3, "  Data type for '{0}' is already equivalent to '{1}'. No change needed.".format(new_name, c_type_str))
                            else:
                                print_indented(3, "  Skipping type application for local variable '{0}': Type '{1}' could not be resolved.".format(new_name, c_type_str))
                        elif not GLOBAL_ENABLE_TYPE_CASTING:
                            print_indented(3, "  Skipping type application for local variable '{0}' due to GLOBAL_ENABLE_TYPE_CASTING=False.".format(new_name))
                    else:
                        # This occurs if `original_name` (e.g., 'uVar1', 'local_res10') was not found
                        # in Ghidra's `function.getLocalVariables()` map after clearing.
                        print_indented(2, "[INFO] Local variable '{0}' (intended as '{1}') not found in Ghidra's current local variables for function {2}. This might mean Ghidra optimized it away, it was identified differently, or it's a decompiler-only pseudo-variable.".format(
                            original_name, new_name, function.getName()))
                        # You might consider logging the stack_offset here if it helps with debugging why
                        # Ghidra didn't create a variable at that location for the original_name.
                        # e.g., print_indented(3, "  JSON offset for '{0}': {1}".format(original_name, hex(int(var_entry.get("offset"), 16))))

                # Add instruction comments
                print_indented(1, "Adding instruction comments...")
                comments_to_add = func_entry.get("comments", [])
                for comment_entry in comments_to_add:
                    offset_str = comment_entry.get("address_offset_from_function_start")
                    comment_text = comment_entry.get("text")

                    if not offset_str or not comment_text:
                        printerr("      Skipping comment entry due to missing data: {0}".format(comment_entry))
                        continue

                    try:
                        comment_address = function.getEntryPoint().add(int(offset_str, 16))
                    except ValueError:
                        printerr("      Invalid address_offset_from_function_start format: {0}. Skipping comment.".format(offset_str))
                        continue

                    comment_type = CodeUnit.PRE_COMMENT

                    try:
                        listing.setComment(comment_address, comment_type, comment_text)
                        print_indented(2, "Added '{0}' comment at {1}: '{2}...'".format("PRE_COMMENT", comment_address, comment_text[:50]))
                    except Exception as e:
                        printerr("      Error adding comment at {0} (type PRE_COMMENT): {1}".format(comment_address, e))
                
                # Define Global Data References
                print_indented(1, "Defining Global Data References...")
                global_data_refs = func_entry.get("global_data_references", [])
                for global_ref in global_data_refs:
                    global_addr_str = global_ref.get("address")
                    new_name = global_ref.get("new_name")
                    c_type_str = global_ref.get("c_type")
                    comment = global_ref.get("comment")

                    if not global_addr_str or not new_name:
                        printerr("      Skipping global data reference entry due to missing address or new_name: {0}".format(global_ref))
                        continue

                    try:
                        global_address = program.getAddressFactory().getAddress(global_addr_str)
                    except Exception as e:
                        printerr("      Invalid global data address '{0}': {1}. Skipping.".format(global_addr_str, e))
                        continue
                    
                    if global_address == None:
                        continue 

                    try:
                        existing_symbol = symbol_table.getPrimarySymbol(global_address)
                    except:
                        existing_symbole = None
                    
                    if existing_symbol:
                        if existing_symbol.getName() != new_name:
                            try:
                                existing_symbol.setName(new_name, SourceType.USER_DEFINED)
                                print_indented(2, "Renamed global symbol at {0} to '{1}'".format(global_address, new_name))
                            except Exception as e:
                                printerr("      Error renaming global symbol at {0} to '{1}': {2}".format(global_address, new_name, e))
                    else:
                        try:
                            symbol_table.createLabel(global_address, new_name, SourceType.USER_DEFINED)
                            print_indented(2, "Created new global label '{0}' at {1}".format(new_name, global_address))
                        except Exception as e:
                            printerr("      Error creating global label '{0}' at {1}: {2}".format(new_name, global_address, e))

                    # if GLOBAL_ENABLE_TYPE_CASTING and c_type_str:
                    #     target_dt = get_or_create_datatype(c_type_str, data_type_manager)
                    #     if target_dt:
                    #         try:
                    #             listing.createData(global_address, target_dt, target_dt.getLength())
                    #             print_indented(2, "Applied type '{0}' to global data at {1}".format(c_type_str, global_address))
                    #         except Exception as e:
                    #             printerr("      Error applying type '{0}' to global data at {1}: {2}".format(c_type_str, global_address, e))
                    #     else:
                    #         print_indented(2, "Skipping type application for global data at '{0}': Type '{1}' not resolved.".format(global_address, c_type_str))
                    # elif not GLOBAL_ENABLE_TYPE_CASTING:
                    #     print_indented(2, "Skipping type application for global data at '{0}' due to GLOBAL_ENABLE_TYPE_CASTING=False.".format(global_address))
                    
                    if comment:
                        try:
                            listing.setComment(global_address, CodeUnit.EOL_COMMENT, comment)
                            print_indented(2, "Added EOL comment to global data at {0}: '{1}...'".format(global_address, comment[:50]))
                        except Exception as e:
                            printerr("      Error adding EOL comment to global data at {0}: {1}".format(global_address, e))

                # Define Subcall Target Functions
                print_indented(1, "Defining Subcall Target Functions...")
                subcall_targets = func_entry.get("subcall_target_functions", [])
                for subcall_target in subcall_targets:
                    target_addr_str = subcall_target.get("address")
                    new_name = subcall_target.get("new_function_name")
                    demangle = subcall_target.get("demangle", False)
                    
                    if not target_addr_str or not new_name:
                        printerr("      Skipping subcall target entry due to missing address or new_function_name: {0}".format(subcall_target))
                        continue
                    
                    try:
                        target_address = program.getAddressFactory().getAddress(target_addr_str)
                    except Exception as e:
                        printerr("      Invalid subcall target address '{0}': {1}. Skipping.".format(target_addr_str, e))
                        continue

                    try:
                        target_function = program.getFunctionManager().getFunctionAt(target_address)
                    except:
                        target_function = None

                    if not target_function:
                        print_indented(2, "[INFO] Subcall target function at {0} not found.".format(target_address))
                        continue
                        # try:
                        #     target_function = createFunction(target_address, None)
                        #     if not target_function:
                        #         printerr("      Failed to create subcall target function at address: {0}. Skipping.".format(target_address))
                        #         continue
                        #     print_indented(2, "Created new subcall target function at {0}".format(target_address))
                        # except Exception as e:
                        #     printerr("      Error creating subcall target function at {0}: {1}. Skipping.".format(target_address, e))
                        #     continue
                    
                    final_target_name = new_name
                    if demangle:
                        final_target_name = apply_demangled_name(target_address, new_name)

                    if final_target_name != target_function.getName():
                        try:
                            target_function.setName(final_target_name, SourceType.USER_DEFINED)
                            print_indented(2, "Renamed subcall target function at {0} to '{1}' (demangle={2})".format(target_address, final_target_name, demangle))
                        except Exception as e:
                            printerr("      Error renaming subcall target function at {0} to '{1}': {2}".format(target_address, final_target_name, e))

                # CHECK VARIABLE COUNT AFTER POTENTIAL TYPE CASTING
                after_attempt_var_count = get_variable_count(function)
                print_indented(1, "Variable count after initial markup attempt: {0}".format(after_attempt_var_count))

                if after_attempt_var_count > initial_var_count:
                    print_indented(1, "[WARNING] Variable count INCREASED (from {0} to {1}) after markup attempt with type casting. Rolling back...".format(initial_var_count, after_attempt_var_count))
                    program.endTransaction(current_transaction_id, False) # ROLLBACK!
                    
                    # --- ATTEMPT 2: Apply without type casting ---
                    print_indented(1, "Attempting to apply markup WITHOUT type casting (parameters/locals will be 'undefinedX' or default)...")
                    fallback_transaction_id = -1
                    try:
                        fallback_transaction_id = program.startTransaction("Markup Function {0} (no casting fallback)".format(function.getName()))
                        
                        # Apply function metadata (name and comment) - always apply
                        if new_func_name:
                            final_func_name = apply_demangled_name(function_address, new_func_name)
                            if final_func_name != function.getName():
                                try:
                                    function.setName(final_func_name, SourceType.USER_DEFINED)
                                    print_indented(2, "Renamed function to '{0}' (fallback)".format(final_func_name))
                                except Exception as e:
                                    printerr("  Error renaming function '{0}' to '{1}' (fallback): {2}".format(function.getName(), final_func_name, e))

                        if func_comment:
                            try:
                                function.setComment(func_comment)
                                print_indented(2, "Added function comment (fallback).")
                            except Exception as e:
                                printerr("  Error adding function comment (fallback): {0}".format(e))

                        # Update function signature (return type and parameters) for fallback
                        # Return type can generally be kept as is, or set to generic if problematic
                        # For this scenario, we keep the resolved `return_dt` from the first attempt.
                        current_signature_fallback = function.getSignature()
                        fallback_signature = current_signature_fallback.copy(data_type_manager)

                        # For parameters, use undefinedN types based on original type length
                        fallback_param_definitions = []
                        for param_entry in parameters_to_process:
                            p_name = param_entry.get("new_name") or param_entry.get("original_name")
                            p_type_str = param_entry.get("c_type")
                            
                            if not p_name:
                                continue
                            
                            p_dt_original_for_size = get_or_create_datatype(p_type_str, data_type_manager)
                            
                            fallback_p_dt = data_type_manager.getDataType("/Undefined/undefined") # Default fallback
                            if not fallback_p_dt: # Last resort if /Undefined/undefined not found
                                fallback_p_dt = data_type_manager.getDataType("/byte")

                            if p_dt_original_for_size and p_dt_original_for_size.getLength() > 0:
                                specific_undefined_dt = data_type_manager.getDataType("/Undefined/undefined{}".format(p_dt_original_for_size.getLength()))
                                if specific_undefined_dt:
                                    fallback_p_dt = specific_undefined_dt
                            else: # Fallback to pointer size undefinedX if type for size not found
                                specific_undefined_dt = data_type_manager.getDataType("/Undefined/undefined{}".format(program_pointer_size))
                                if specific_undefined_dt:
                                    fallback_p_dt = specific_undefined_dt
                            
                            fallback_param_definitions.append(ParameterDefinitionImpl(p_name, fallback_p_dt, None))
                        
                        if fallback_param_definitions:
                            try:
                                fallback_signature.setArguments(fallback_param_definitions)
                                print_indented(2, "Applied parameters WITHOUT type casting (using 'undefinedX').")
                            except Exception as e:
                                printerr("  Error setting parameters in fallback signature: {0}".format(e))
                        
                        # Apply the updated fallback signature
                        try:
                            function.setSignature(fallback_signature, SourceType.USER_DEFINED)
                            print_indented(2, "Applied function signature (return type and parameters) for fallback.")
                        except Exception as e:
                            printerr("  Error applying fallback function signature: {0}".format(e))

                        # Apply local variables (no type casting)
                        try:
                            VariableUtilities.clearVariables(function, monitor) # Corrected
                            print_indented(2, "Cleared existing local variables for fallback using VariableUtilities.clearVariables.")
                        except Exception as e:
                            printerr("  Error clearing existing local variables for fallback: {0}. Continuing without clearing.".format(e))

                        for var_entry in local_vars_to_process:
                            new_name = var_entry.get("new_name")
                            c_type_str = var_entry.get("c_type")
                            offset_str = var_entry.get("offset")

                            if not new_name or not offset_str:
                                continue
                            
                            try:
                                stack_offset = int(offset_str, 16)
                            except ValueError:
                                continue
                            
                            local_dt_original_for_size = get_or_create_datatype(c_type_str, data_type_manager)
                            
                            fallback_local_dt = data_type_manager.getDataType("/Undefined/undefined") # Default fallback
                            if not fallback_local_dt: # Last resort if /Undefined/undefined not found
                                fallback_local_dt = data_type_manager.getDataType("/byte")

                            if local_dt_original_for_size and local_dt_original_for_size.getLength() > 0:
                                specific_undefined_dt = data_type_manager.getDataType("/Undefined/undefined{}".format(local_dt_original_for_size.getLength()))
                                if specific_undefined_dt:
                                    fallback_local_dt = specific_undefined_dt
                            else: # Fallback to pointer size undefinedX if type for size not found
                                specific_undefined_dt = data_type_manager.getDataType("/Undefined/undefined{}".format(program_pointer_size))
                                if specific_undefined_dt:
                                    fallback_local_dt = specific_undefined_dt


                            if fallback_local_dt:
                                try:
                                    VariableUtilities.createStackVariable(function, new_name, stack_offset, fallback_local_dt, SourceType.USER_DEFINED) # Corrected
                                    print_indented(2, "Applied local variable '{0}' (using '{1}') at offset {2} (fallback).".format(new_name, fallback_local_dt.getName(), hex(stack_offset)))
                                except Exception as e:
                                    printerr("      Error applying local variable '{0}' (fallback): {1}".format(new_name, e))

                        # Comments, Global Data, and Subcall Targets are safe and reapplied
                        print_indented(1, "Adding instruction comments (fallback)...")
                        for comment_entry in comments_to_add:
                            offset_str = comment_entry.get("address_offset_from_function_start")
                            comment_text = comment_entry.get("text")
                            if not offset_str or not comment_text: continue
                            try:
                                comment_address = function.getEntryPoint().add(int(offset_str, 16))
                                listing.setComment(comment_address, CodeUnit.PRE_COMMENT, comment_text)
                                print_indented(2, "Added '{0}' comment at {1}: '{2}...' (fallback)".format("PRE_COMMENT", comment_address, comment_text[:50]))
                            except Exception as e:
                                printerr("      Error adding comment at {0} (fallback): {1}".format(comment_address, e))
                        
                        print_indented(1, "Defining Global Data References (fallback)...")
                        for global_ref in global_data_refs:
                            global_addr_str = global_ref.get("address")
                            new_name = global_ref.get("new_name")
                            c_type_str = global_ref.get("c_type")
                            comment = global_ref.get("comment")
                            if not global_addr_str or not new_name: continue
                            try:
                                global_address = program.getAddressFactory().getAddress(global_addr_str)
                                existing_symbol = symbol_table.getPrimarySymbol(global_address)
                                if existing_symbol:
                                    if existing_symbol.getName() != new_name:
                                        existing_symbol.setName(new_name, SourceType.USER_DEFINED)
                                        print_indented(2, "Renamed global symbol at {0} to '{1}' (fallback)".format(global_address, new_name))
                                else:
                                    symbol_table.createLabel(global_address, new_name, SourceType.USER_DEFINED)
                                    print_indented(2, "Created new global label '{0}' at {1} (fallback)".format(new_name, global_address))
                                
                                # In fallback, for global data, we could still apply the type
                                # if it's considered generally safe (e.g., simple types).
                                # Or, apply an undefinedX if we want strict "no aggressive type casting"
                                # For now, I'll allow full typing on global data even in fallback,
                                # as it typically doesn't cause variable explosion issues.
                                if c_type_str:
                                    target_dt_global = get_or_create_datatype(c_type_str, data_type_manager)
                                    if target_dt_global:
                                        try:
                                            listing.createData(global_address, target_dt_global, -1, DataUtilities.ClearDataMode.CLEAR_ALL_CONFLICT_DATA)
                                            print_indented(2, "Applied type '{0}' to global data at {1} (fallback)".format(c_type_str, global_address))
                                        except Exception as e:
                                            printerr("      Error applying type '{0}' to global data at {1} (fallback): {2}".format(c_type_str, global_address, e))
                                    else:
                                        print_indented(2, "Skipping type application for global data at '{0}': Type '{1}' not resolved (fallback).".format(global_address, c_type_str))
                                else:
                                    print_indented(2, "Skipping type application for global data at '{0}': No C type specified (fallback).".format(global_address))

                                if comment:
                                    listing.setComment(global_address, CodeUnit.EOL_COMMENT, comment)
                                    print_indented(2, "Added EOL comment to global data at {0}: '{1}...' (fallback)".format(global_address, comment[:50]))
                            except Exception as e:
                                printerr("      Error defining global data at {0} (fallback): {1}".format(global_address, e))
                        
                        print_indented(1, "Defining Subcall Target Functions (fallback)...")
                        for subcall_target in subcall_targets:
                            target_addr_str = subcall_target.get("address")
                            new_name = subcall_target.get("new_function_name")
                            demangle = subcall_target.get("demangle", False)
                            if not target_addr_str or not new_name: continue
                            try:
                                target_address = program.getAddressFactory().getAddress(target_addr_str)
                                target_function = program.getFunctionManager().getFunctionAt(target_address)
                                if not target_function:
                                    target_function = createFunction(target_address, None)
                                    if not target_function: continue
                                final_target_name = new_name
                                if demangle:
                                    final_target_name = apply_demangled_name(target_address, new_name)
                                if final_target_name != target_function.getName():
                                    target_function.setName(final_target_name, SourceType.USER_DEFINED)
                                    print_indented(2, "Renamed subcall target function at {0} to '{1}' (fallback)".format(target_address, final_target_name))
                            except Exception as e:
                                printerr("      Error defining subcall target function at {0} (fallback): {1}".format(target_address, e))

                        # Final check after fallback
                        after_fallback_var_count = get_variable_count(function)
                        print_indented(1, "Variable count after fallback attempt (no type casting): {0}".format(after_fallback_var_count))
                        
                        if after_fallback_var_count <= initial_var_count:
                            program.endTransaction(fallback_transaction_id, True) # Commit fallback
                            print_indented(1, "Successfully applied function analysis without aggressive type casting for '{0}'.".format(function.getName()))
                        else:
                            printerr("  [FATAL] Variable count STILL INCREASED even after fallback ({0} to {1}). Rolling back all changes for this function.".format(initial_var_count, after_fallback_var_count))
                            program.endTransaction(fallback_transaction_id, False) # Rollback fallback as well
                            print_indented(1, "Function '{0}' was restored to its state prior to this script's attempt.".format(function.getName()))

                    except Exception as e:
                        printerr("  FATAL ERROR during fallback application for function '{0}': {1}".format(function.getName(), e))
                        if fallback_transaction_id != -1:
                            program.endTransaction(fallback_transaction_id, False) # Ensure rollback on error
                else:
                    # Variable count did not increase, commit the type-casted version
                    program.endTransaction(current_transaction_id, True)
                    print_indented(1, "Successfully applied function analysis with type casting for '{0}'.".format(function.getName()))

            except Exception as e:
                printerr("  Error applying analysis to function '{0}': {1}".format(function.getName(), e))
                if current_transaction_id != -1:
                    program.endTransaction(current_transaction_id, False) # Ensure rollback on error
            
            print_indented(1, "Finished processing function: {0}. Please check the Decompiler view.".format(function.getName()))


# Run the script
if __name__ == "__main__":
    apply_analysis_from_json_string(INLINE_JSON_DATA)