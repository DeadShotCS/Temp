# decomp_disasm_printer.py
# A Ghidra Python script to grab the decompilation and disassembly from function addresses passed as arguments.
# @author chat_gemini
# @category _NEW_
# @menupath _NEW_/Decompilation Disassembly Printer

from ghidra.app.decompiler import DecompInterface
from ghidra.util.task import ConsoleTaskMonitor
from ghidra.program.model.listing import Function, CodeUnit
from ghidra.program.model.address import Address
from ghidra.program.model.symbol import SymbolTable, Symbol, Reference 

import re 

# Global decompiler interface for efficiency if many functions are processed
decompiler = None

def initialize_decompiler():
    global decompiler
    if decompiler is None:
        decompiler = DecompInterface()
        decompiler.openProgram(currentProgram)

def get_selected_function():
    """
    Attempts to get the function currently selected in the listing.
    This function is copied here so decomp_disasm_printer.py can work standalone
    if no arguments are provided.
    """
    current_addr = currentLocation.getAddress()
    if current_addr:
        function = getFunctionContaining(current_addr)
        if function:
            print("Selected function: '{}' at {}".format(function.getName(), function.getEntryPoint()))
            return function
    
    print("No function found or selected. Please place your cursor inside the desired function in the Listing view.")
    return None

def get_function_by_address(address_string):
    """
    Gets a function by its address string.
    """
    try:
        addr = currentProgram.getAddressFactory().getAddress(address_string)
        function = currentProgram.getFunctionManager().getFunctionAt(addr)
        if function:
            print("Processing function: '{}' at {}".format(function.getName(), function.getEntryPoint()))
            return function
        else:
            print("No function found at address: {}".format(address_string))
            return None
    except Exception as e:
        print("Error parsing address string '{}': {}".format(address_string, e))
        return None

def get_decompilation(function):
    """
    Gets the decompiled pseudocode for a given function as a single string.
    """
    if not function:
        return "" # Return empty string if no function

    output_lines = []
    output_lines.append("\n--- Decompiling Function: {} ---".format(function.getName()))
    
    global decompiler # Use the global decompiler instance
    if decompiler is None:
        initialize_decompiler() # Initialize if not already

    results = decompiler.decompileFunction(function, 0, ConsoleTaskMonitor())

    if results.decompileCompleted():
        decompiled_code = results.getDecompiledFunction().getC()
        output_lines.append(decompiled_code)
        output_lines.append("\n--- Decompilation Complete ---")
    else:
        output_lines.append("Decompilation failed for {}. Status: {}".format(function.getName(), results.getStatus()))
        output_lines.append("Decompiler error message: {}".format(results.getErrorMessage()))
    
    return "\n".join(output_lines)

def get_disassembly(function):
    """
    Gets the disassembly (instructions) for a given function as a single string,
    with manual symbol resolution and removal of "0x" prefix from resolved names.
    """
    if not function:
        return "" # Return empty string if no function

    output_lines = []
    output_lines.append("\n--- Disassembly for Function: {} ---".format(function.getName()))
    
    listing = currentProgram.getListing()
    symbol_table = currentProgram.getSymbolTable()
    function_manager = currentProgram.getFunctionManager()
    address_factory = currentProgram.getAddressFactory() 
    
    body = function.getBody()
    
    code_units = listing.getCodeUnits(body, True) # True for forward
    
    for unit in code_units:
        instruction = listing.getInstructionAt(unit.getAddress())
        if instruction:
            mnemonic = instruction.getMnemonicString()
            
            all_instruction_references = instruction.getReferencesFrom()
            
            operand_parts = []
            for i in range(instruction.getNumOperands()):
                operand_str = instruction.getDefaultOperandRepresentation(i)
                
                current_operand_references = [
                    ref for ref in all_instruction_references if ref.getOperandIndex() == i
                ]
                
                resolved_name = None
                if current_operand_references:
                    ref_target_addr = current_operand_references[0].toAddress
                    
                    target_func = function_manager.getFunctionAt(ref_target_addr)
                    if target_func:
                        resolved_name = target_func.getName()
                    else:
                        target_symbol = symbol_table.getPrimarySymbol(ref_target_addr)
                        if target_symbol:
                            resolved_name = target_symbol.getName()
                
                if resolved_name:
                    hex_matches = re.finditer(r'(?P<prefix>0x)?(?P<addr>[0-9a-fA-F]+)(?P<suffix>h)?', operand_str, re.IGNORECASE)
                    
                    best_match = None 
                    
                    for match in hex_matches:
                        try:
                            potential_addr_str_bare = match.group('addr')
                            matched_ghidra_addr = address_factory.getAddress(potential_addr_str_bare) 
                            if matched_ghidra_addr == ref_target_addr:
                                best_match = match
                                break
                        except:
                            pass 
                    
                    if best_match:
                        start_idx = best_match.start() 
                        end_idx = best_match.end()     
                        operand_str = operand_str[:start_idx] + resolved_name + operand_str[end_idx:]

                operand_parts.append(operand_str)
            
            operand_string = ", ".join(operand_parts)
            
            full_instruction_str = "{}: {}".format(instruction.getAddress(), "{:<10} {}".format(mnemonic, operand_string)) 
            output_lines.append(full_instruction_str)
    
    output_lines.append("\n--- Disassembly Complete ---")
    return "\n".join(output_lines)


def main():
    # Get arguments passed to this script
    print("--- decomp_disasm_printer.py: Script started ---")
    scriptArgs = getScriptArgs()
    print("decomp_disasm_printer.py: Received scriptArgs: {}".format(scriptArgs))
    print("decomp_disasm_printer.py: Type of scriptArgs: {}".format(type(scriptArgs)))

    function_addresses_str = list(scriptArgs) 
    print("decomp_disasm_printer.py: Converted to Python list: {}".format(function_addresses_str))
    print("decomp_disasm_printer.py: Type of converted list: {}".format(type(function_addresses_str)))

    # Now, check the *length* of the Python list
    if not function_addresses_str: # This will now correctly catch an empty list
        print("decomp_disasm_printer.py: No function addresses provided as arguments. Attempting to process selected function.")
        target_function = get_selected_function()
        if target_function:
            functions_to_process = [target_function]
        else:
            print("decomp_disasm_printer.py: No function to process.")
            return
    else:
        # Process each address string passed as an argument
        functions_to_process = []
        for arg in function_addresses_str: # Iterate over the Python list
            func = get_function_by_address(arg)
            if func:
                functions_to_process.append(func)
    
    # Ensure there are functions to process after parsing arguments
    if not functions_to_process:
        print("decomp_disasm_printer.py: No valid functions found from provided arguments or selection.")
        return

    initialize_decompiler()
    
    for function in functions_to_process:
        # Get the full decompilation string
        decompilation_output = get_decompilation(function)
        print(decompilation_output)

        # Get the full disassembly string
        disassembly_output = get_disassembly(function)
        print(disassembly_output)
    
    if decompiler is not None:
        decompiler.dispose()

if __name__ == '__main__':
    main()