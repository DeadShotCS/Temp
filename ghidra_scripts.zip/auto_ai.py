

FORMAT_REQUEST = r"""
For all function marking requests. Return an `INLINE_JSON_DATA` with the following format and information. Additionally, please try to add the following; brief description of expected input and return variables and their meaning with each part having their own line and indent, local variable and value meaning at their declaration/initializations/assignments, any subcall meanings or guesses, and parts where a assumed pass by reference or return value is manipulated with its meaning. Try to be concise where possible and elaborate on any meanings or values that may not be intuitive. If meaning is retained, keep comments to one per decompilation line at maximum. Please mark the start of each comment with your name and a marker such as `[GUESS: 50%]` with your confidence. You will get the disassembly and decompilation for the same function. 

Avoid commenting on assembly instructions or decompiled lines where their meaning or direct action is immediately obvious (e.g., `NOP` instructions, simple register moves without complex context, clear arithmetic operations unless the result's purpose is non-intuitive). Focus comments on inferences, high-level purpose, data flow beyond direct assignment, control flow logic, or non-obvious variable meanings.

Try to identify any direct or potential bugs or vulnerabilities in the code; Include a `[VULN: 50%]` marker with your confidence. When getting decompilation and disassembly, controlled parameters may be specified but otherwise assume input may or may not be user controlled. Please include a concise summary of each vulnerability in the function level description similar to input/outputs.

Beyond function-specific details, also identify all unique global variables and subcalls encountered. For each, suggest a more descriptive `new_name` and provide its `c_type`. For subcalls, also list their estimated `c_type` (return type) and common `parameters` with their `c_type`.

Do not fully trust already marked up portions. If you think there is relevance to change a non-default name then indicate that in a comment and change the new name in the INLINE_JSON_DATA.

Use all available code to derive your results. Do not treat each diassembly / decompile as a isolated instance as you may need to attempt to trace call parameters to derive vulnerabilities.

VERY IMPORTANT: When renaming functions, do not remove or alter existing prefixes like oop::. For example, oop::decode_impl_alternate should remain oop::decode_impl_alternate if no other rename is specified, or if a rename is specified, ensure the oop:: prefix is kept.

When generating the INLINE_JSON_DATA, all string values within the JSON object (e.g., for function_comment, comment fields, new_name, c_type, etc.) must strictly adhere to JSON string escaping rules. This means:

- Newlines (\n) must be escaped as \\n.
- Backslashes (\) must be escaped as \\\\.
- Double quotes (") within a string must be escaped as \\".
- Tabs (\t) must be escaped as \\t.
- Avoid other unescaped control characters (ASCII 0-31)."

```
INLINE_JSON_DATA = {
  "typedef_definitions": [
    {
      "name": "",
      "base_type": "",
      "comment": ""
    }
  ],
  "struct_definitions": [
    {
      "name": "",
      "members": [
        {"name": "", "type": "", "offset": ""},
        {"name": "", "type": "", "offset": "", "comment": ""},
        {"name": "", "type": "", "offset": ""}
      ],
      "comment": ""
    }
  ],
  "function_updates": [
    {
      "function_identification": {
        "address": ""
      },
      "function_metadata": {
        "new_function_name": "",
        "function_comment": ""
      },
      "parameters": [
        {
          "original_name": "",
          "new_name": "",
          "c_type": ""
        }
      ],
      "local_variables": [
        {
          "original_name": "",
          "new_name": "",
          "c_type": "",
          "offset": ""
        }
      ],
      "comments": [
        {
          "address_offset_from_function_start": "",
          "text": ""
        }
      ],
      "global_data_references": [
        {
          "address": "",
          "new_name": "",
          "c_type": "",
          "comment": ""
        }
      ],
      "subcall_target_functions": [
        {
          "address": "",
          "new_function_name": "",
          "demangle": False
        }
      ]
    }
  ]
}
```
"""

# Get Current Function and Subcalls.py
# @author chat_gemini
# @category _NEW_
# @menupath _NEW_/Get Current Function and Subcalls

from ghidra.program.model.listing import Function
from ghidra.program.model.symbol import RefType

import os
import tempfile
import java.util.Date # For timestamping output

# Define a well-known, fixed path for inter-script communication (for addresses)
GHIDRA_SHARED_FILE_PATH = os.path.join(tempfile.gettempdir(), "ghidra_shared_addrs.txt")

# Define a single, common output file path for ALL script output
GHIDRA_OUTPUT_DIR = os.path.join(os.path.expanduser('~'), "Ghidra_Analysis_Output")
UNIFIED_OUTPUT_FILE_PATH = os.path.join(GHIDRA_OUTPUT_DIR, "ghidra_unified_analysis_output.txt")


# Helper function to write to the unified output file
def write_unified_output(message, file_handle):
    file_handle.write(message + "\n")
    # Optional: print to Ghidra console for immediate feedback on the caller side
    # print(message)


def get_subcall_tree(func, depth, current_depth=0, visited_paths=None):
    """
    Recursively builds a tree-like structure of function calls up to a specified depth.
    
    Args:
        func (ghidra.program.model.listing.Function): The current function to analyze.
        depth (int): The maximum depth to traverse.
        current_depth (int): The current recursion depth.
        visited_paths (set): A set of (depth, function_address) tuples to detect and prevent
                             infinite loops in recursive or cyclic call graphs within a path.
    
    Returns:
        dict: A dictionary representing the current function and its subcall hierarchy,
              or None if the function is null or depth limit is reached, or a cycle is detected.
              Format: {'function': Function_obj, 'depth': int, 'subcalls': [list_of_sub_trees]}
    """
    if visited_paths is None:
        visited_paths = set()
    
    if func is None or current_depth > depth:
        return None

    # Use a unique identifier for the current path segment to detect cycles
    current_path_segment = (current_depth, func.getEntryPoint())
    if current_path_segment in visited_paths:
        # Detected a cycle in this specific call path, return None to stop this branch
        return None 

    # Create a new set for the recursive call to track its specific path
    new_visited_paths = set(visited_paths)
    new_visited_paths.add(current_path_segment)

    direct_subcalls_nodes = []
    
    listing = currentProgram.getListing()
    function_manager = currentProgram.getFunctionManager()

    for instruction in listing.getInstructions(func.getBody(), True):
        for ref in instruction.getReferencesFrom():
            if ref.getReferenceType().isCall():
                call_addr = ref.getToAddress()
                called_func = function_manager.getFunctionAt(call_addr)
                if called_func:
                    sub_tree = get_subcall_tree(called_func, depth, current_depth + 1, new_visited_paths)
                    if sub_tree: # Only add if the sub-call successfully produced a tree (not a cycle or depth limit)
                        direct_subcalls_nodes.append(sub_tree)
    
    return {'function': func, 'depth': current_depth, 'subcalls': direct_subcalls_nodes}


def print_call_tree(node, file_handle):
    """
    Recursively prints the function call tree with indentation to the file handle.
    """
    if not node:
        return

    func = node['function']
    depth = node['depth']
    indent = "  " * depth # 2 spaces per depth level

    write_unified_output("{}Depth {}: {} ({})".format(indent, depth, func.getName(), func.getEntryPoint()), file_handle)

    for sub_node in node['subcalls']:
        print_call_tree(sub_node, file_handle)

def collect_unique_functions(node, unique_set):
    """
    Recursively collects all unique function objects from the call tree into a set.
    """
    if not node:
        return
    unique_set.add(node['function'])
    for sub_node in node['subcalls']:
        collect_unique_functions(sub_node, unique_set) 


def main():
    # Ensure the output directory exists
    if not os.path.exists(GHIDRA_OUTPUT_DIR):
        try:
            os.makedirs(GHIDRA_OUTPUT_DIR)
        except Exception as e:
            popup("Error creating output directory {}: {}".format(GHIDRA_OUTPUT_DIR, e))
            print("Error creating output directory {}: {}".format(GHIDRA_OUTPUT_DIR, e)) # Log to Ghidra console too
            return

    program = currentProgram
    if not program:
        popup("No program open. Please open a program first.")
        # Attempt to log this critical error to the file even if program is not open
        # This requires opening in 'w' mode to clear any old content and then appending.
        try:
            with open(UNIFIED_OUTPUT_FILE_PATH, 'w') as out_file_err:
                write_unified_output("--- Analysis started at: {} ---".format(java.util.Date()), out_file_err)
                write_unified_output("Unified analysis output will be written to: {}".format(UNIFIED_OUTPUT_FILE_PATH), out_file_err)
                write_unified_output("-" * 80, out_file_err)
                write_unified_output("Error: No program open.", out_file_err)
                write_unified_output("--- Script finished with error ---", out_file_err)
        except Exception as file_e:
            print("Fatal: Could not write error message to file: {}".format(file_e))
        return

    # --- ADDED: Retrieve binary info ---
    binary_name = program.getName()
    architecture = program.getLanguage().getProcessor().toString()
    executable_format = program.getExecutableFormat()
    image_base = program.getImageBase()
    # -----------------------------------

    # Phase 1: Write header and call hierarchy from this script
    with open(UNIFIED_OUTPUT_FILE_PATH, 'w') as out_file: # Open in WRITE mode to clear

        write_unified_output(FORMAT_REQUEST, out_file)
        write_unified_output("--- Analysis started at: {} ---".format(java.util.Date()), out_file)
        write_unified_output("-" * 80, out_file)
        # --- ADDED: Write binary info ---
        write_unified_output("Binary Name: {}".format(binary_name), out_file)
        write_unified_output("Architecture: {}".format(architecture), out_file)
        write_unified_output("Executable Format: {}".format(executable_format), out_file)
        write_unified_output("Image Base: {}".format(image_base), out_file)
        write_unified_output("-" * 80, out_file)
        # -----------------------------------
        

        current_address = currentLocation.getAddress()
        current_function = getFunctionContaining(current_address)
        
        if not current_function:
            popup("Cursor is not within a function. Please place the cursor inside a function.")
            write_unified_output("Error: Cursor is not within a function.", out_file)
            return

        depth_str = askString("Subcall Depth", "Enter the maximum depth for subcall traversal (0 for direct subcalls only):", "1")
        try:
            subcall_depth = int(depth_str)
            if subcall_depth < 0:
                raise ValueError
        except ValueError:
            popup("Invalid depth. Please enter a non-negative integer.")
            write_unified_output("Error: Invalid depth entered.", out_file)
            return

        monitor.setMessage("Analyzing function: {} at {}".format(current_function.getName(), current_function.getEntryPoint()))
        write_unified_output("Analysis starting from: {} ({})\n".format(current_function.getName(), current_function.getEntryPoint()), out_file)

        # Build the hierarchical call tree
        call_tree_root = get_subcall_tree(current_function, subcall_depth)

        if call_tree_root:
            write_unified_output("Call Hierarchy (up to depth {}):".format(subcall_depth), out_file)
            print_call_tree(call_tree_root, out_file)
        else:
            write_unified_output("No call hierarchy found for {} up to depth {}.".format(current_function.getName(), subcall_depth), out_file)
        
        # Collect all unique functions from the tree for processing in the other script
        unique_functions_for_file = set()
        collect_unique_functions(call_tree_root, unique_functions_for_file)
        
        function_addresses_to_print = [str(f.getEntryPoint()) for f in 
                                       sorted(list(unique_functions_for_file), key=lambda f: f.getEntryPoint())]

        # This 'try' block needs its own 'except' clause.
        try: 
            # Write addresses to the fixed-path file, one per line
            with open(GHIDRA_SHARED_FILE_PATH, 'w') as f:
                for addr in function_addresses_to_print:
                    f.write(addr + "\n")
            
            write_unified_output("\n--- Inter-script Communication ---", out_file)
            write_unified_output("Addresses written to shared file: {}".format(GHIDRA_SHARED_FILE_PATH), out_file)
            write_unified_output("Calling decomp_disasm_printer.py to append output to unified file...", out_file)
        
        # Add the 'except' block back for the inner file operation
        except Exception as e:
            # If there's an error writing the shared addresses file, log it
            write_unified_output("Error writing shared addresses file {}: {}".format(GHIDRA_SHARED_FILE_PATH, e), out_file)
            # You might want to 'return' here if this error is critical enough to stop the script.
            # For now, we'll let it try to call the next script even if this fails.
            
    # Phase 2: Call the second script, which will append to the file
    try:
        runScript("decomp_disasm_printer.py")
    except Exception as e:
        # If runScript fails, we need to log this to the file.
        # So re-open in append mode just for this error message.
        with open(UNIFIED_OUTPUT_FILE_PATH, 'a') as out_file_append:
            write_unified_output("Error calling decomp_disasm_printer.py: {}".format(e), out_file_append)

    # Phase 3: Add final messages from this script (after receiver script has run)
    with open(UNIFIED_OUTPUT_FILE_PATH, 'a') as out_file_final: # Re-open in APPEND mode
        monitor.setMessage("Subcall analysis complete.")
        write_unified_output("\n--- Get Current Function and Subcalls.py finished ---", out_file_final)
        print("Check {} for full output.".format(UNIFIED_OUTPUT_FILE_PATH), out_file_final)

if __name__ == '__main__':
    main()